"""Exhaustive finite Model-A invariants. Python 3.10+, standard library."""
import json,itertools,csv,collections
from pathlib import Path
R=Path(__file__).resolve().parents[1]; O=R/'results';O.mkdir(exist_ok=True)
def dump(n,a):(O/n).write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
def span(b):
 s={0}
 for x in b:s|={a^x for a in s}
 return tuple(sorted(s))
def basis(s):
 b=[]
 for f in sorted(s):
  if f not in span(b):b.append(f)
 return b
def push(m,p):return sum(1<<p[i] for i in range(len(p)) if m>>i&1)
def norm(m,p):
 z=push(m,p);return z^(65535 if z&1 else 0)
rows=[r.split() for r in (R/'inputs/models.txt').read_text().splitlines()];aspects=rows[0][2:]
names={int(r[1],2)^15:r[0] for r in rows};P={int(r[1],2)^15:tuple(aspects.index(a) for a in r[2:]) for r in rows}
source=(R/'inputs/project_tables.md').read_text()
for r in rows:
 assert any([s.strip() for s in line.replace(chr(92),'').replace('*','').split('|')[1:-1]]==[r[0]]+r[2:] for line in source.splitlines())
ss=json.loads((R/'inputs/systems24.json').read_text());systems={s['label']:tuple(s['functions']) for s in ss if s['kind']=='new'}
for s in systems.values():assert len(s)==16 and span(basis(s))==s and all(f==0 or f.bit_count()==8 for f in s)
seeds=json.loads((R/'inputs/new_systems_seed.json').read_text())
assert all(tuple(s['functions'])==systems[f"B{s['structure_id']}_{s['candidate']}"] for s in seeds)
core=set.intersection(*(set(s) for s in systems.values()))
autos=json.loads((R/'inputs/table_automorphisms1024.json').read_text())
assert len({(tuple(a['alpha']),tuple(a['beta']),tuple(a['pi'])) for a in autos})==1024
for a in autos:
 assert all(P[a['pi'][x]][a['alpha'][i]]==a['beta'][P[x][i]] for x in range(16) for i in range(8))
# Completeness of imported automorphisms: any triple is determined by alpha and pi(0).
G=set(P.values());normal=[]
for p in itertools.permutations(range(8)):
 if all(tuple(p[g[p.index(i)]] for i in range(8)) in G for g in G):normal.append(p)
assert len(normal)*16==len(autos)
image=[[push(b,P[x]) for b in range(256)] for x in range(16)]
parts=[];allblocks=set();stab={}
for label,S in systems.items():
 stab[label]=[a for a in autos if tuple(sorted(norm(f,a['pi']) for f in S))==S]
 for rank in (1,2,3):
  subs=sorted({span(c) for c in itertools.combinations(S[1:],rank) if len(span(c))==2**rank})
  assert len(subs)=={1:15,2:35,3:15}[rank]
  for j,L in enumerate(subs,1):
   bs=basis(L);groups=collections.defaultdict(int)
   for x in range(16):groups[sum(((f>>x)&1)<<i for i,f in enumerate(bs))]|=1<<x
   blocks=sorted(groups.values());assert len(blocks)==2**rank and all(b.bit_count()==16//2**rank for b in blocks)
   parts.append(dict(id=f'{label}_r{rank}_{j:02}',system=label,rank=rank,subspace=L,basis=bs,core_dimension=(len(set(L)&core)).bit_length()-1,blocks=blocks))
   allblocks.update(blocks)
print('partitions',len(parts),'unique blocks',len(allblocks),flush=True)
profiles={};union={};exactext={}
with (O/'all_unions.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['type_mask','function_mask','aspect_union_mask','extent_mask'])
 for pole in sorted(allblocks):
  xs=[x for x in range(16) if pole>>x&1]; U=[0]*256
  for b in range(1,256):
   for x in xs:U[b]|=image[x][b]
  union[pole]=U;mu=[min(U[b].bit_count() for b in range(1,256) if b.bit_count()==k) for k in range(1,9)]
  witnesses=[];extent_all=65535;extent_min=65535;single=[];exact=[]
  for b in range(1,256):
   a=U[b];ex=sum((image[x][b]&~a==0)<<x for x in range(16));w.writerow([pole,b,a,ex]);extent_all&=ex
   if ex==pole:single.append(b)
   if a.bit_count()==b.bit_count() and b!=255:exact.append(b)
   if a.bit_count()==mu[b.bit_count()-1]:witnesses.append([b,a,ex]);extent_min&=ex
  assert extent_all&pole==pole and extent_min&pole==pole
  profiles[pole]=dict(types=[names[x] for x in xs],size=len(xs),mu=mu,min_witnesses=witnesses,exact_function_masks=exact,individual_characterizing_masks=single,closure_all=extent_all,closure_min=extent_min)
# Exact minimal conjunction via dynamic programming over excluded types, all attainable masks <= 65536.
for pole,p in profiles.items():
 target=65535^pole;clauses={target&~z[2]:z[0] for z in p['min_witnesses'] if target&~z[2]}
 dp={0:[]}
 for excluded,b in sorted(clauses.items()):
  for m,bs in list(dp.items()):
   n=m|excluded
   if n not in dp or len(dp[n])>len(bs)+1:dp[n]=bs+[b]
 p['minimum_minimizer_conjunction']=dp.get(target)
dump('partitions.json',parts);dump('profiles.json',profiles)
# Orbits of partitions and their blocks under each system stabilizer, with explicit witnesses.
orbits=[];porbits=[]
for label in systems:
 aa=stab[label]
 for rank in (1,2,3):
  pp=[p for p in parts if p['system']==label and p['rank']==rank];byL={tuple(p['subspace']):p for p in pp};remaining=set(byL)
  while remaining:
   L=min(remaining);members={tuple(sorted(norm(f,a['pi']) for f in L)) for a in aa};assert members<=set(byL)
   porbits.append(dict(system=label,rank=rank,representative=byL[L]['id'],members=sorted(byL[m]['id'] for m in members)))
   remaining-=members
  remaining={b for p in pp for b in p['blocks']}
  while remaining:
   b=min(remaining);witness={}
   for a in aa:witness.setdefault(push(b,a['pi']),a['id'])
   members=set(witness);assert members<=remaining
   for c,aid in witness.items():
    a=autos[aid];assert profiles[c]['mu']==profiles[b]['mu']
    assert all(union[c][push(B,a['alpha'])]==push(union[b][B],a['beta']) for B in range(256))
   orbits.append(dict(system=label,rank=rank,representative=b,members=sorted(members),witnesses=witness,mu=profiles[b]['mu']))
   remaining-=members
# Every refinement relation and strict improvement by arity (nontrivial k=1..7).
ref=[]
for p in parts:
 if p['rank']==3:continue
 for q in parts:
  if q['system']!=p['system'] or q['rank']!=p['rank']+1 or not set(p['subspace'])<set(q['subspace']):continue
  children=[]
  for child in q['blocks']:
   parent=next(b for b in p['blocks'] if b&child==child)
   assert all(a<=b for a,b in zip(profiles[child]['mu'],profiles[parent]['mu']))
   children.append(dict(parent=parent,child=child,strict_k=[k+1 for k,(a,b) in enumerate(zip(profiles[child]['mu'][:7],profiles[parent]['mu'][:7])) if a<b]))
  ref.append(dict(parent_partition=p['id'],child_partition=q['id'],blocks=children))
dump('block_orbits.json',orbits);dump('partition_orbits.json',porbits);dump('refinements.json',ref)
summary={}
for label in systems:
 summary[label]={}
 for rank in (1,2,3):
  pp=[p for p in parts if p['system']==label and p['rank']==rank];bb=[b for p in pp for b in p['blocks']]
  count=collections.Counter(tuple(profiles[b]['mu']) for b in bb)
  summary[label][rank]=dict(partitions=len(pp),block_occurrences=len(bb),unique_blocks=len(set(bb)),partition_orbits=sum(o['system']==label and o['rank']==rank for o in porbits),block_orbits=sum(o['system']==label and o['rank']==rank for o in orbits),profiles=[dict(mu=k,count=v) for k,v in sorted(count.items())],characterized_by_all=sum(profiles[b]['closure_all']==b for b in bb),characterized_by_min=sum(profiles[b]['closure_min']==b for b in bb),single_characterized=sum(bool(profiles[b]['individual_characterizing_masks']) for b in bb),with_exact=sum(bool(profiles[b]['exact_function_masks']) for b in bb),conjunction_lengths=dict(sorted(collections.Counter(str(len(profiles[b]['minimum_minimizer_conjunction'])) if profiles[b]['minimum_minimizer_conjunction'] is not None else 'impossible' for b in bb).items())))
dump('summary.json',summary);dump('encoding.json',dict(type_index=names,aspect_bit_order=aspects,function_bit_order=list(range(1,9)),systems=systems,common_core=sorted(core)))
dump('checks.json',dict(verified=True,automorphisms=1024,systems=8,partitions=len(parts),block_occurrences=sum(len(p['blocks']) for p in parts),distinct_blocks=len(allblocks),union_rows=len(allblocks)*255,refinement_edges=len(ref),symmetry_union_equivariance=True))
print(json.dumps(summary['B1_1'],ensure_ascii=False));print(json.dumps(summary['B1_2'],ensure_ascii=False))

import json,collections,itertools,csv
from pathlib import Path
R=Path(__file__).resolve().parents[1];O=R/'results'
def read(n):return json.loads((O/n).read_text())
def dump(n,a):(O/n).write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
pf={int(k):v for k,v in read('profiles.json').items()};parts=read('partitions.json');enc=read('encoding.json');rows=[r.split() for r in (R/'inputs/models.txt').read_text().splitlines()];base=rows[0][2:];P={int(r[1],2)^15:tuple(base.index(a) for a in r[2:]) for r in rows}
def push(m,p):return sum(1<<p[i] for i in range(8) if m>>i&1)
exact={}
for b,v in pf.items():
 xs=[x for x in range(16) if b>>x&1];p0=P[xs[0]];gens=[tuple(p0.index(P[x][i]) for i in range(8)) for x in xs];remaining=set(range(8));orb=[]
 while remaining:
  s={min(remaining)}
  while True:
   t=s|{g[i] for g in gens for i in s}
   if t==s:break
   s=t
  orb.append(sorted(s));remaining-=s
 exact[b]=dict(reference_type=xs[0],relative_generators=gens,function_orbits=orb)
 derived=set()
 for flags in range(1,2**len(orb)-1):derived.add(sum(1<<i for j,o in enumerate(orb) if flags>>j&1 for i in o))
 assert derived==set(v['exact_function_masks'])
dump('exact_invariant_orbits.json',exact)
hetero=[]
for p in parts:
 profiles={tuple(pf[b]['mu']) for b in p['blocks']}
 if len(profiles)>1:hetero.append(p['id'])
dump('additional_summary.json',dict(closure_sizes={str(size):dict(sorted(collections.Counter(v['closure_all'].bit_count() for v in pf.values() if v['size']==size).items())) for size in (8,4,2)},heterogeneous_partitions=hetero,exact_invariant_theorem_verified=True))
for label in ['B1_1','B1_2']:
 print(label)
 for o in read('block_orbits.json'):
  if o['system']==label and o['rank']==1:
   b=o['representative'];v=pf[b];best=min(v['min_witnesses'],key=lambda z:(z[1].bit_count(),z[0].bit_count(),z[0]))
   print(b,len(o['members']),v['mu'][:4],v['types'],'best',best,'closure',v['closure_all'])
 print('hetero',[p for p in hetero if p.startswith(label+'_')])
for size in (4,2):
 for b,v in pf.items():
  if v['size']==size and v['minimum_minimizer_conjunction'] and len(v['minimum_minimizer_conjunction'])==2:
   print('two clause',b,v['types'],v['minimum_minimizer_conjunction'],[z for z in v['min_witnesses'] if z[0] in v['minimum_minimizer_conjunction']]);break
 for b,v in pf.items():
  if v['size']==size and v['closure_all']!=b:
   print('nonclosed',b,v['types'],'closure',v['closure_all'], 'mu',v['mu']);break
# Ordered joint observations preserve correlations lost by aspect unions.
joint={};coordinate_sets={b:[i for i in range(8) if b>>i&1] for b in range(1,256)}
observations={b:[tuple(P[x][i] for i in ii) for x in range(16)] for b,ii in coordinate_sets.items()}
jointfile=(O/'all_joint_extents.csv').open('w',newline='');writer=csv.writer(jointfile);writer.writerow(['type_mask','function_mask','joint_extent_mask'])
for pole,v in pf.items():
 xs=[x for x in range(16) if pole>>x&1];ww=[];closures={k:65535 for k in range(1,9)}
 for b,obs in observations.items():
  values={obs[x] for x in xs};ext=sum((obs[x] in values)<<x for x in range(16));k=b.bit_count();closures[k]&=ext;writer.writerow([pole,b,ext])
  if ext==pole:ww.append(b)
 k=min(b.bit_count() for b in ww)
 joint[pole]=dict(minimum_single_projection_arity=k,all_minimum_function_masks=[b for b in ww if b.bit_count()==k],minimum_all_projections_arity=min(k for k,c in closures.items() if c==pole),closures=closures)
jointfile.close()
assert len({(P[x][0],P[x][1]) for x in range(16)})==16
dump('joint_invariants.json',joint)
print('joint arities',dict(collections.Counter(v['minimum_single_projection_arity'] for v in joint.values())))
summary=read('summary.json')
for label in ['B1_1','B1_3','B25_2','B25_3']:assert summary[label]==summary['B1_1']
for label in ['B1_2','B1_4','B25_1','B25_4']:assert summary[label]==summary['B1_2']
for label in enc['systems']:
 for rank in (1,2,3):assert sum(p['id'] in hetero for p in parts if p['system']==label and p['rank']==rank)==(0 if rank==1 else 2)
assert all(v['closure_all']==v['closure_min'] for v in pf.values())
assert all(pf[b]['mu']==pf[65535^b]['mu'] for b in pf if pf[b]['size']==8)

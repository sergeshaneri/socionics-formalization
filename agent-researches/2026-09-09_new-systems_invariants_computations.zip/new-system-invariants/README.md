# Model-A new-system invariants

Read report.md (Russian). Python 3.10+, standard library only.

Reproduce from the extracted directory:

```bash
python3 code/reproduce.py > results/run.log
python3 code/analyze.py > results/analysis.log
python3 code/build_report.py
```

All paths resolve relative to each script, not the current working directory.
Integer masks are documented in report.md and results/encoding.json.
Input models and system identifiers are frozen from the prior symmetry study.
The scripts verify the input table against project_tables.md, balanced code spaces,
all imported table automorphisms and completeness, every minimal subset union,
all orbit transports, all refinement inequalities, exact-invariant orbit theorem,
all joint-projection extents, and the report's classwise and closure summaries.

No scientific meaning beyond this finite incidence model is assumed.

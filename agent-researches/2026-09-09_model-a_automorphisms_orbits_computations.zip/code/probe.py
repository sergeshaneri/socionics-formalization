import itertools,json,collections
from pathlib import Path
R=Path(__file__).resolve().parents[1]
rows=[r.split() for r in (R/'inputs/models.txt').read_text().splitlines()];base=rows[0][2:]
P={int(r[1],2)^15:tuple(base.index(a) for a in r[2:]) for r in rows};rev={p:x for x,p in P.items()};V=range(16)
def comp(a,b):return tuple(a[b[i]] for i in range(len(a)))
def inv(p):return tuple(p.index(i) for i in range(len(p)))
N=[]
for a in itertools.permutations(range(8)):
 ai=inv(a)
 if all(comp(comp(a,P[x]),ai) in rev for x in (1,2,8)):
  phi=tuple(rev[comp(comp(a,P[x]),ai)] for x in V);N.append((a,phi))
print('N',len(N),'C',sum(phi==tuple(V) for a,phi in N),'induced',len({p for a,p in N}))
models=[]
for a,phi in N:
 for c in V:
  pi=tuple(rev[comp(P[c],P[phi[x]])] for x in V);models.append((a,c,pi))
print('triples',len(models),'type perms',len({pi for a,c,pi in models}))
(R/'results/probe.json').write_text(json.dumps(dict(N=[dict(alpha=a,phi=phi) for a,phi in N],models=[dict(alpha=a,c=c,pi=p) for a,c,p in models]),indent=2))

from pathlib import Path
import json,re
R=Path(__file__).resolve().parents[1]
def load(n):return json.loads((R/'results'/n).read_text())
def label(n):
 if n.startswith('D'):return '$D_{'+str(int(n[1:]))+'}$'
 a,b=n[1:].split('_');return '$B_{'+a+','+b+'}$'
def labels(ns):return ', '.join(label(n) for n in ns)
def table(h,rows):return '\n'.join(['| '+' | '.join(h)+' |','| '+' | '.join(['---']*len(h))+' |']+['| '+' | '.join(map(str,row))+' |' for row in rows])
lev=load('equivalence_levels.json');info={a['label']:a for a in load('systems24.json')};profiles=load('profile_representatives.json');pr={n:a['profile'] for a in profiles for n in a['systems']}
stab=load('system_stabilizers.json');s=(R/'code/report_template.md').read_text()
rows=[]
for i,orb in enumerate(lev['full']['system_orbits'],1):
 a=info[orb[0]];kind='кубические' if len(orb)==8 else 'квадратичные' if a['kind']=='old' else 'левые брейсы' if a['left_brace'] else 'правые брейсы'
 rows.append([i,labels(orb),len(orb),len(stab[orb[0]]['type_action_ids']),kind])
s=s.replace('{{ORBITS}}',table(['Орбита','Системы','Размер',r'Порядок стабилизатора в $\Gamma$','Класс'],rows))
struc=load('compatible_structures_orbits.json')
s=s.replace('{{STRUCTURES}}',table(['Структура','Орбита','Стабилизатор в $N$','Порядок линейного образа','Переносы: элементы через типы'],[[a['id'],str(a['orbit']),len(a['normalizer_stabilizer']),a['linear_image_order'],', '.join(a['translation_kernel_names'])] for a in struc]))
levelnames={'full':'Все автоморфизмы с сохранением ролей','reference_ILE':'ИЛЭ фиксирован','source_E8_setwise':'Исходные E8 сохраняются целиком','nality_oriented':'Нальность закреплена с полярностью','named_traits_unoriented':'Каждое из семи разбиений закреплено','all_traits_oriented':'Все семь признаков и их полярности закреплены','functions_pointwise':'Все функции закреплены по отдельности','aspects_pointwise':'Все аспекты закреплены по отдельности'}
s=s.replace('{{LEVELS}}',table(['Условие','Троек','Действий на типах','Орбит систем','Орбит структур на функциях'],[[levelnames[n],a['triple_count'],a['effective_type_count'],len(a['system_orbits']),len(a['structure_orbits'])] for n,a in lev.items()]))
s=s.replace('{{REF_ORBITS}}','**При фиксированном ИЛЭ:**\n\n'+ '; '.join(labels(a) for a in lev['reference_ILE']['system_orbits'])+'.')
s=s.replace('{{NAMED_ORBITS}}','**При сохранении каждого из семи исходных разбиений без закрепления полярности:**\n\n'+'; '.join(labels(a) for a in lev['named_traits_unoriented']['system_orbits'])+'.')
s=s.replace('{{DUALITY_ORBITS}}',table(['Класс при разрешённом обмене функций и аспектов','Размер'],[[labels(a),len(a)] for a in load('duality_comparison.json')['system_orbits']]))
s=s.replace('{{PROFILES}}',table(['Системы одной орбиты',r'$(\mu(1),\mu(2),\mu(3),\mu(4))$'],[[labels(a['systems']),str(tuple(a['profile']))] for a in profiles]))
assert '{{' not in s
(R/'REPORT.md').write_text(s)
# A human-readable companion to the complete JSON witness catalogues.
out=['# Орбиты, стабилизаторы и явные преобразования модели А','','Дата: 9 сентября 2026 года. Номера D и B сохранены из предыдущих исследований; номера 1,16,25,30 на функциях являются другой нумерацией.','','## Каталог 24 систем','',table(['Система','Название / происхождение','$h$ для прежних систем','Аффинных левых отношений','Аффинных правых отношений'],[[label(n),a['name'],'$'+a['h']+'$' if a['kind']=='old' else '—',a['affine_left_count'],a['affine_right_count']] for n,a in info.items()]),'']
for n,a in lev.items():
 out += ['## '+levelnames[n],'',f"Троек: {a['triple_count']}; различных действий на типах: {a['effective_type_count']}.",'',table(['Орбита','Размер'],[[labels(o),len(o)] for o in a['system_orbits']]),'']
models=load('table_automorphisms1024.json');w=load('equivalence_witnesses.json');normal=load('normalizer64.json');base=(R/'inputs/models.txt').read_text().splitlines()[0].split()[2:];names={int(r.split()[1],2)^15:r.split()[0] for r in (R/'inputs/models.txt').read_text().splitlines()}
def cycles(p,ns):
 seen=set();out=[]
 for i in range(len(p)):
  if i in seen:continue
  c=[];j=i
  while j not in seen:seen.add(j);c.append(ns[j]);j=p[j]
  if len(c)>1:out.append('('+' → '.join(map(str,c))+' → '+str(c[0])+')')
 return '; '.join(out) or 'тождество'
out += ['## Явные свидетели эквивалентности систем','','В циклах стрелка задаёт образ элемента, последняя стрелка возвращает в начало.','']
for a in w['systems']:
 if a['source']==a['target']:continue
 m=models[a['triple_id']]
 out += [f"**{label(a['source'])} → {label(a['target'])}; тройка {a['triple_id']}.**",'', 'Функции: '+cycles(m['alpha'],list(range(1,9)))+'.','', 'Аспекты: '+cycles(m['beta'],base)+'.','', 'Типы: '+cycles(m['pi'],[names[x] for x in range(16)])+'.','']
out += ['## Свидетель эквивалентности структур 1 и 25','']
z=next(z for z in w['structures'] if z['source']==1 and z['target']==25)
out += [f"Элемент нормализатора {z['normalizer_id']}. Функции: "+cycles(z['alpha'],list(range(1,9)))+'.','', 'Соответствующая перестановка аспектов при фиксированном ИЛЭ: '+cycles(z['alpha'],base)+'.','']
poles=load('pole_orbits.json')
out += ['## Орбиты полюсов представителей девяти классов','','Показаны все полюсные орбиты стабилизатора выбранной системы; маски и свидетели всех остальных полюсов сохранены в JSON.','']
for orbit in lev['full']['system_orbits']:
 n=orbit[0]
 out += ['### '+label(n),'',table(['Размер орбиты','Орбитальный признак','Маска представителя','Типы полюса'],[[z['size'],'да' if z['orbital'] else 'нет',z['representative'],', '.join(z['representative_types'])] for z in poles[n]]),'']
out += ['## Обращение отношений: соответствие систем','',table(['Система','Образ при обращении'],[[label(n),label(v)] for n,v in load('duality_comparison.json')['inversion_mapping'].items()]),'']
(R/'ORBIT_TABLES_AND_WITNESSES.md').write_text('\n'.join(out)+'\n')

"""Exact automorphisms of the supplied three-sorted Model-A incidence table.
Python >=3.10, standard library, run from any working directory.
"""
import itertools,json,collections,csv,re
from pathlib import Path
R=Path(__file__).resolve().parents[1];OUT=R/'results';OUT.mkdir(exist_ok=True)
V=range(16);F=range(8);ID8=tuple(F);ID16=tuple(V)
def dump(n,o):(OUT/n).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def csvout(n,rows):
 with (OUT/n).open('w',newline='',encoding='utf-8') as f:csv.writer(f).writerows(rows)
def comp(a,b):return tuple(a[b[i]] for i in range(len(a)))
def inv(p):return tuple(p.index(i) for i in range(len(p)))
def parity(x):return x.bit_count()%2
def span(gs):
 s={0}
 for g in gs:s|={f^g for f in s}
 return s
def u(x):return (x&8)//2|((((x>>2)^(x>>1))&1)<<1)|(x&1)
def h(k,a):return sum((k>>i&1)*(a&m==m) for i,m in enumerate([6,5,3,7]))%2
def mask(fn):return sum(fn(x)<<x for x in V)
def poly(k):return '+'.join(s for i,s in enumerate(['ed','eq','dq','edq']) if k>>i&1) or '0'
rows=[r.split() for r in (R/'inputs/models.txt').read_text().splitlines()];base=rows[0][2:];names={int(r[1],2)^15:r[0] for r in rows}
P={int(r[1],2)^15:tuple(base.index(a) for a in r[2:]) for r in rows};rev={p:x for x,p in P.items()};G=set(P.values())
def op(x,y):return rev[comp(P[x],P[y])]
inverse=tuple(rev[inv(P[x])] for x in V)
assert len(G)==16 and all(op(x,y)==x^y^(6*((x&1)*(u(y)>>1&1))) for x in V for y in V)
# Check model rows and the source feature systems against the full source file.
modelrows={};arows={};frows={};reinin={}
for line in (R/'inputs/project_tables.md').read_text().splitlines():
 if not line.lstrip().startswith('|'):continue
 z=[s.strip() for s in line.replace('\\','').replace('*','').split('|')[1:-1]]
 if not z:continue
 if z[0] in base and len(z)==9 and set(z[1:])<={'+','-'}:arows[z[0]]=[int(s=='-') for s in z[1:]]
 m=re.search(r'\(([1-8])\)',z[0])
 if m and len(z)==9 and set(z[1:])<={'+','-'}:frows[int(m[1])]=[int(s=='-') for s in z[1:]]
 if z[0] in names.values() and len(z)==9 and set(z[1:])==set(base):modelrows[z[0]]=z[1:]
 if z[0] in names.values() and len(z)==17 and set(z[1:])<={'0','1'}:reinin[z[0]]=[1-int(s) for s in z[1:]]
assert len(arows)==len(frows)==8 and len(reinin)==len(modelrows)==16
assert all(modelrows[r[0]]==r[2:] for r in rows)
sourceF={sum(frows[i+1][j]<<i for i in F) for j in F};sourceA={sum(arows[base[i]][j]<<i for i in F) for j in F};assert sourceF==sourceA
# Source systems reconstructed from original exact partitions.
signames={'I+':'ИЛЭ','I-':'ИЭЭ','S-':'СЭИ','S+':'СЛИ','E+':'ЭСЭ','E-':'ЭИЭ','L-':'ЛИИ','L+':'ЛСИ','F-':'СЛЭ','F+':'СЭЭ','T+':'ИЭИ','T-':'ИЛИ','P+':'ЛИЭ','P-':'ЛСЭ','R+':'ЭИИ','R-':'ЭСИ'}
signed={s:next(x for x in V if names[x]==n) for s,n in signames.items()}
O={mask(lambda x:parity(l&u(x))) for l in F};systems={};info={}
for a in json.loads((R/'inputs/systems.json').read_text()):
 walls=set()
 for aa,bb in a['pairs']:
  aa={signed[z] for z in aa};bb={signed[z] for z in bb};assert len(aa)==len(bb)==8 and not aa&bb and aa|bb==set(V)
  if 0 not in aa:aa,bb=bb,aa
  walls.add(sum((x not in aa)<<x for x in V))
 k=next(k for k in V if walls=={mask(lambda x,l=l,k=k:(x>>2&1)^h(k,u(x))^parity(l&u(x))) for l in F})
 name=f"D{a['id']:02}";systems[name]=tuple(sorted(O|walls));info[name]=dict(source_id=a['id'],name=a['name'],h=poly(k),kind='old')
assert set(systems['D15'])=={mask(lambda x:reinin[names[x]][j]) for j in V}
for a in json.loads((R/'inputs/new_systems_seed.json').read_text()):
 name=f"B{a['structure_id']}_{a['candidate']}";S=tuple(a['functions']);assert set(S)==span(a['basis']) and len(S)==16 and all(f==0 or f.bit_count()==8 for f in S)
 assert len({tuple(f>>x&1 for f in a['basis']) for x in V})==16
 systems[name]=S;info[name]=dict(kind='new',name=name,left_brace=a['left_brace_counterexample'] is None,right_brace=a['right_brace_counterexample'] is None)
assert len(systems)==len(set(systems.values()))==24
for name,S in systems.items():
 B=set(S)
 def normalized_pull(f,g,left):
  z=sum((f>>(op(g,x) if left else op(x,g))&1)<<x for x in V)
  return z^(65535 if z&1 else 0)
 lc=sum(all(normalized_pull(f,g,True) in B for f in S) for g in V)
 rc=sum(all(normalized_pull(f,g,False) in B for f in S) for g in V)
 info[name]['affine_left_count']=lc;info[name]['affine_right_count']=rc
 if info[name]['kind']=='new':assert info[name]['left_brace']==(lc==16) and info[name]['right_brace']==(rc==16)
newcore=set.intersection(*(set(S) for name,S in systems.items() if info[name]['kind']=='new'))
assert newcore=={mask(lambda x:parity(l&u(x))) for l in (0,1,2,3)}

byS={s:n for n,s in systems.items()};labels=list(systems)
# Normalizer: test a generating set, then independently verify all 16 elements.
gen=(1,2,8);words={0:()};todo=[0]
for x in todo:
 for j,g in enumerate(gen):
  y=op(x,g)
  if y not in words:words[y]=words[x]+(j,);todo.append(y)
assert len(words)==16
normal=[]
for a in itertools.permutations(F):
 ai=inv(a)
 if not all(comp(comp(a,P[x]),ai) in G for x in gen):continue
 phi=tuple(rev[comp(comp(a,P[x]),ai)] for x in V)
 normal.append(dict(id=len(normal),alpha=a,phi=phi))
N={tuple(z['alpha']) for z in normal};central=[z for z in normal if tuple(z['phi'])==ID16]
assert len(N)==64 and len(central)==4 and all(comp(a,b) in N for a in N for b in N)
real_aut={tuple(a['phi']) for a in normal};assert len(real_aut)==16
# Abstract automorphisms, without reference to the 8-point action.
abstract=[]
for images in itertools.product(V,repeat=3):
 phi=[]
 for x in V:
  y=0
  for j in words[x]:y=op(y,images[j])
  phi.append(y)
 phi=tuple(phi)
 if len(set(phi))!=16:continue
 if all(phi[op(x,y)]==op(phi[x],phi[y]) for x in V for y in V):abstract.append(phi)
assert len(set(abstract))==len(abstract)==64 and real_aut<=set(abstract)
H=frozenset(x for x in V if P[x][0]==0);Hclass={frozenset(op(op(g,x),inverse[g]) for x in H) for g in V}
assert H=={0,2} and len(Hclass)==2
assert all((phi in real_aut)==(frozenset(phi[x] for x in H) in Hclass) for phi in abstract)
# All sort-preserving table automorphisms beta*P_x*alpha^{-1}=P_pi(x).
models=[]
for z in normal:
 a=tuple(z['alpha']);ai=inv(a)
 for c in V:
  beta=comp(P[c],a);pi=tuple(op(c,z['phi'][x]) for x in V)
  assert all(comp(comp(beta,P[x]),ai)==P[pi[x]] for x in V)
  models.append(dict(id=len(models),normalizer_id=z['id'],c=c,alpha=a,beta=beta,pi=pi))
pis=sorted({a['pi'] for a in models});pid={p:i for i,p in enumerate(pis)};piset=set(pis)
assert len(models)==1024 and len(pis)==256 and all(comp(p,q) in piset for p in pis for q in pis)
assert set(collections.Counter(a['pi'] for a in models).values())=={4}
for a in models:a['type_action_id']=pid[a['pi']]
# Efficient push-forward of subset masks; normalized functions represent unoriented partitions.
look={}
def ensure(pi):
 if pi not in look:look[pi]=([sum(1<<pi[i] for i in range(8) if m>>i&1) for m in range(256)],[sum(1<<pi[i+8] for i in range(8) if m>>i&1) for m in range(256)])
def push(f,pi):
 ensure(pi);lo,hi=look[pi];return lo[f&255]|hi[f>>8]
def normpush(f,pi):
 z=push(f,pi);return z^(65535 if z&1 else 0)
def act(S,pi):return tuple(sorted(normpush(f,pi) for f in S))
closure={act(S,p) for S in systems.values() for p in pis};assert closure==set(systems.values())
actions={p:tuple(byS[act(systems[n],p)] for n in labels) for p in pis}
# Thirty feature systems on F; four compatible with G.
families={}
for r in itertools.permutations(range(1,8)):
 c=(0,)+r;S=tuple(sorted(sum(parity(c[i]&a)<<i for i in F) for a in F));families.setdefault(S,c)
Fstruct={i:(S,c) for i,(S,c) in enumerate(sorted(families.items()),1)}
def push8(f,a):return sum(1<<a[i] for i in F if f>>i&1)
def norm8(f,a):
 z=push8(f,a);return z^(255 if z&1 else 0)
def structact(S,a):return tuple(sorted(norm8(f,a) for f in S))
compatible={i:(S,c) for i,(S,c) in Fstruct.items() if all(structact(S,P[x])==S for x in V)}
assert set(compatible)=={1,16,25,30} and set(compatible[30][0])==sourceF
structby={S:i for i,(S,c) in compatible.items()}
structsummary=[]
for i,(S,c) in compatible.items():
 ci={z:j for j,z in enumerate(c)};linparts={};ker=[]
 for x in V:
  fx=[c[P[x][ci[z]]] for z in F];b=fx[0];cols=tuple(fx[z]^b for z in (1,2,4));linparts[x]=cols
  if cols==(1,2,4):ker.append(x)
 orb={structby[structact(S,z['alpha'])] for z in normal};stab=[z['id'] for z in normal if structact(S,z['alpha'])==S]
 structsummary.append(dict(id=i,orbit=sorted(orb),normalizer_stabilizer=stab,translation_kernel=ker,translation_kernel_names=[names[x] for x in ker],linear_image_order=len(set(linparts.values())),traits=S))
# Precisely specified levels of semantic/structural fixing.
nality=170
levels={
 'full':[a['id'] for a in models],
 'reference_ILE':[a['id'] for a in models if a['c']==0],
 'source_E8_setwise':[a['id'] for a in models if set(structact(tuple(sourceF),a['alpha']))==sourceF and set(structact(tuple(sourceA),a['beta']))==sourceA],
 'nality_oriented':[a['id'] for a in models if push8(nality,a['alpha'])==nality and push8(nality,a['beta'])==nality],
 'named_traits_unoriented':[a['id'] for a in models if all(norm8(f,a['alpha'])==f for f in sourceF) and all(norm8(f,a['beta'])==f for f in sourceA)],
 'all_traits_oriented':[a['id'] for a in models if all(push8(f,a['alpha'])==f for f in sourceF) and all(push8(f,a['beta'])==f for f in sourceA)],
 'functions_pointwise':[a['id'] for a in models if a['alpha']==ID8],
 'aspects_pointwise':[a['id'] for a in models if a['beta']==ID8]
}
assert levels['full']==levels['source_E8_setwise']
level_results={}
for lev,ids in levels.items():
 pp=sorted({models[j]['pi'] for j in ids});orbits=[];seen=set()
 for n in labels:
  if n in seen:continue
  orb={byS[act(systems[n],p)] for p in pp};seen|=orb;orbits.append(sorted(orb,key=lambda z:labels.index(z)))
 assert seen==set(labels)
 # For each level, preserve precisely the compatible structures that meet that level's constraints.
 so=[];done=set()
 for i,(S,c) in compatible.items():
  if i in done:continue
  oo={structby[structact(S,models[j]['alpha'])] for j in ids};done|=oo;so.append(sorted(oo))
 level_results[lev]=dict(triple_count=len(ids),effective_type_count=len(pp),triple_ids=ids,type_action_ids=[pid[p] for p in pp],system_orbits=orbits,structure_orbits=so)
# System stabilizers and signed pole orbits, with explicit map witnesses.
stabilizers={};pole_results={};wall_results={};representative_triple={p:next(a for a in models if a['pi']==p)['id'] for p in pis}
for name,S in systems.items():
 stab=[p for p in pis if act(S,p)==S];stabilizers[name]=dict(type_action_ids=[pid[p] for p in stab],triple_ids=[a['id'] for a in models if a['pi'] in stab])
 poles={f for f in S if f}|{f^65535 for f in S if f};seen=set();orbits=[]
 for f in sorted(poles):
  if f in seen:continue
  oo={push(f,p) for p in stab};assert oo<=poles;seen|=oo
  witnesses=[]
  for target in sorted(oo):
   p=next(p for p in stab if push(f,p)==target);tid=representative_triple[p];a=models[tid]
   # All eight individual cells for each source type in this pole certify transport of every subset invariant.
   assert all(P[a['pi'][x]][a['alpha'][i]]==a['beta'][P[x][i]] for x in V if f>>x&1 for i in F)
   witnesses.append(dict(target_mask=target,type_action_id=pid[p],triple_id=tid))
  orbits.append(dict(representative=f,representative_types=[names[x] for x in V if f>>x&1],poles=sorted(oo),size=len(oo),orbital=(f in O or f^65535 in O),witnesses=witnesses))
 assert seen==poles and sum(z['size'] for z in orbits)==30
 pole_results[name]=orbits
 if info[name]['kind']=='old':
  walls=[z for z in orbits if not z['orbital']];assert len(walls)==1 and walls[0]['size']==16
  wall_results[name]=dict(stabilizer_effective=len(stab),stabilizer_triples=len(stabilizers[name]['triple_ids']),orbit=walls[0])
 else:assert sorted(z['size'] for z in orbits if not z['orbital'])==[4,4,8,8]
# Polarity-invariant minima for one representative of each full orbit of old systems.
profile_reps=[]
for orbit in level_results['full']['system_orbits']:
 name=orbit[0]
 if info[name]['kind']!='old':continue
 f=wall_results[name]['orbit']['representative'];xs=[x for x in V if f>>x&1];results=[]
 for k in range(1,5):
  candidates=[]
  for subset in itertools.combinations(F,k):
   union={P[x][i] for x in xs for i in subset};candidates.append((len(union),subset,sorted(union)))
  best=min(z[0] for z in candidates);results.append(dict(k=k,minimum=best,witnesses=[dict(functions=[i+1 for i in b],aspects=[base[i] for i in a]) for count,b,a in candidates if count==best]))
 profile_reps.append(dict(systems=orbit,representative_system=name,pole_mask=f,pole_types=[names[x] for x in xs],profile=[r['minimum'] for r in results],minima=results))
# Compare with role exchange (transpose): this is not a sort-preserving automorphism.
assert inverse not in piset
extended=sorted(piset|{comp(p,inverse) for p in pis});assert len(extended)==512
ext_orbits=[];seen=set()
for name,S in systems.items():
 if name in seen:continue
 oo={byS[act(S,p)] for p in extended};seen|=oo;ext_orbits.append(sorted(oo,key=lambda z:labels.index(z)))
inversionmap={name:byS[act(S,inverse)] for name,S in systems.items()}
assert inversionmap['D14']=='D15'
# Both left and right cosets underlying the duality equation are checked on all cells.
assert all(comp(comp(a['beta'],inv(P[x])),inv(a['alpha']))==P[op(a['c'],normal[a['normalizer_id']]['phi'][inverse[x]])] for a in models for x in V)
assert {tuple(a['alpha']) for a in central}=={P[x] for x in (0,6,8,14)}
# Explicit counter-witness for abstract automorphisms not preserving the point action.
nonreal=next(p for p in abstract if p not in real_aut)
dump('nonrealizable_abstract_example.json',dict(phi=nonreal,image_of_H=sorted(nonreal[x] for x in H),allowed_conjugates=[sorted(s) for s in sorted(Hclass,key=lambda a:tuple(sorted(a)))]))
# Canonical witnesses between equivalent structures and systems.
sysw=[]
for orbit in level_results['full']['system_orbits']:
 ref=orbit[0]
 for target in orbit:
  p=next(p for p in pis if byS[act(systems[ref],p)]==target);sysw.append(dict(source=ref,target=target,triple_id=representative_triple[p],type_action_id=pid[p]))
structw=[]
for a in structsummary:
 for target in a['orbit']:
  n=next(n for n in normal if structact(compatible[a['id']][0],n['alpha'])==compatible[target][0]);structw.append(dict(source=a['id'],target=target,normalizer_id=n['id'],alpha=n['alpha']))
# Generators of permutation groups, for compact independent checking.
def generators(group):
 group=set(group);identity=tuple(range(len(next(iter(group)))));known={identity};gens=[]
 for g in sorted(group):
  if g in known:continue
  gens.append(g);todo=list(known)
  for p in todo:
   for q in gens:
    z=comp(p,q)
    if z not in known:known.add(z);todo.append(z)
  if known==group:break
 assert known==group
 return gens
Ngens=generators(N);pgens=generators(piset)
extset=set(extended);assert all(comp(p,g) in extset for p in extended for g in pgens+[inverse])
dump('normalizer64.json',normal);dump('centralizer4.json',central);dump('abstract_automorphisms64.json',[dict(phi=p,realizable=p in real_aut,point_stabilizer_image=sorted(p[x] for x in H)) for p in abstract]);dump('table_automorphisms1024.json',models)
dump('effective_actions256.json',[dict(id=pid[p],pi=p,witness_triple=representative_triple[p]) for p in pis]);dump('group_generators.json',dict(normalizer=Ngens,type_actions=pgens))
dump('systems24.json',[dict(label=n,functions=systems[n],**info[n]) for n in labels]);dump('equivalence_levels.json',level_results);dump('compatible_structures_orbits.json',structsummary);dump('system_stabilizers.json',stabilizers);dump('pole_orbits.json',pole_results);dump('wall_transitivity.json',wall_results);dump('profile_representatives.json',profile_reps);dump('duality_comparison.json',dict(inversion=inverse,inversion_mapping=inversionmap,extended_type_count=512,extended_triple_count=2048,system_orbits=ext_orbits))
dump('equivalence_witnesses.json',dict(systems=sysw,structures=structw))
csvout('system_actions.csv',[['type_action_id','source','target']]+[[pid[p],n,actions[p][i]] for p in pis for i,n in enumerate(labels)])
csvout('model_coordinates.csv',[['x','type','P_x_1_to_8']]+[[x,names[x],','.join(str(i+1) for i in P[x])] for x in V])
csvout('structure_actions.csv',[['normalizer_id','source','target']]+[[z['id'],i,structby[structact(S,z['alpha'])]] for z in normal for i,(S,c) in compatible.items()])
checks=dict(source_models=16,source_reinin_rows=16,source_aspect_rows=8,source_function_rows=8,permutations_tested_for_normalizer=40320,normalizer_order=64,centralizer_order=4,abstract_aut_order=64,realizable_abstract_aut_order=16,table_automorphisms=1024,effective_type_actions=256,kernel_on_types=4,initial_systems=24,closure_systems=len(closure),old_system_orbits=7,new_system_orbits=2,total_system_orbits=len(level_results['full']['system_orbits']),compatible_structure_orbits=len(level_results['full']['structure_orbits']),wall_transitive_systems=len(wall_results),model_cell_equalities=1024*16*8,all_assertions_passed=True)
dump('checks.json',checks);print(json.dumps(checks,ensure_ascii=False,indent=2))
for name,z in level_results.items():print(name,z['triple_count'],z['effective_type_count'],z['system_orbits'],z['structure_orbits'])
print('DUALITY:',ext_orbits)

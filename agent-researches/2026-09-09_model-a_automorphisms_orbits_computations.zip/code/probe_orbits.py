import json,collections,itertools
from pathlib import Path
R=Path(__file__).resolve().parents[1];V=range(16)
src=[dict(id=int(a['label'][1:]),k=sum(1<<i for i,n in enumerate(['ed','eq','dq','edq']) if n in a['h'].split('+'))) for a in json.load(open(R/'results/systems24.json')) if a['kind']=='old']
def u(x):return (x&8)//2|((((x>>2)^(x>>1))&1)<<1)|(x&1)
def h(k,a):return sum((k>>i&1)*(a&m==m) for i,m in enumerate([6,5,3,7]))%2
def mask(f):return sum(f(x)<<x for x in V)
orb={mask(lambda x:(l&u(x)).bit_count()%2) for l in range(8)}
S={f"D{a['id']:02}":tuple(sorted(orb|{mask(lambda x,k=a['k'],l=l:(x>>2&1)^h(k,u(x))^((l&u(x)).bit_count()%2)) for l in range(8)})) for a in src}
for a in json.load(open(R/'inputs/new_systems_seed.json')):S[f"B{a['structure_id']}_{a['candidate']}"]=tuple(a['functions'])
models=json.load(open(R/'results/probe.json'))['models'];pis=sorted({tuple(a['pi']) for a in models});look={}
for pi in pis:
 lo=[sum(1<<pi[i] for i in range(8) if m>>i&1) for m in range(256)];hi=[sum(1<<pi[i+8] for i in range(8) if m>>i&1) for m in range(256)];look[pi]=(lo,hi)
def push(f,pi):
 lo,hi=look[pi];a=lo[f&255]|hi[f>>8];return a^(65535 if a&1 else 0)
def act(S,pi):return tuple(sorted(push(f,pi) for f in S))
closure={act(s,pi) for s in S.values() for pi in pis};print('closure',len(closure))
seen=set()
for name,s in S.items():
 if s in seen:continue
 orbit={act(s,pi) for pi in pis};seen|=orbit
 print(name,'orbit',len(orbit),'known',[n for n,t in S.items() if t in orbit])
 # Under a system's stabilizer, are its non-O poles homogeneous?
 stab=[pi for pi in pis if act(s,pi)==s];poles=set(s)-orb;poles|={f^65535 for f in poles};seenp=set();sizes=[]
 for f in sorted(poles):
  if f in seenp:continue
  po={ (look[pi][0][f&255]|look[pi][1][f>>8]) for pi in stab};seenp|=po;sizes.append(len(po))
 print('stable types',len(stab),'pole orbits',sizes)

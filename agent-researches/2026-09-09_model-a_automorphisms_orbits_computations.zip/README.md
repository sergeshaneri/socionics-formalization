# Model-A automorphisms and orbits of 24 trait systems

Research date: 2026-09-09. Python 3.10+, standard library only. No network or files outside the extracted archive are required.

## Reproduce

```bash
python3 code/reproduce.py
python3 code/build_report.py
```

The main script recreates result files and runs all assertions. To recreate the saved console output, redirect stdout to results/run.log. Two retained preliminary probes can also be run after the main script:

```bash
python3 code/probe.py
python3 code/probe_orbits.py
```

Their saved stdout is in results/probe.log and results/probe_orbits.log. probe.py recreates results/probe.json; probe_orbits.py reads the fully reconstructed system index in results/systems24.json. The independent probe verifies the full-group system orbits and wall transitivity separately from the main export code.

## Inputs and provenance

- inputs/project_tables.md is the full user-provided project Markdown, containing all Model-A, Reinin, Aspecton and Functionon rows.
- inputs/models.txt is a compact copy of the 16 models. Each row is checked against project_tables.md.
- inputs/systems.json is the factual list of exact type halves of the 16 Varlawend systems, from https://varlawend.blogspot.com/2023/08/there-are-16-distinct-systems-of-16.html . Every polynomial is reconstructed from those partitions.
- inputs/new_systems_seed.json contains the eight complete new function systems from the preceding 2026-09-08 coefficient-space study. Their group closure, order, balanced nonconstant functions, distinct type codes and left/right affinity are checked again. Their coefficient-space derivation is the provenance of these seeds, not a new part of this study.

No other historical results are used as unchecked conclusions. The source table index numbers take priority over Functionon's row ordering.

## Encodings

A type x is encoded as raw_code XOR 1111, with bits e,n,l,q from high to low. Bit 1 denotes introversion, sensing, ethics, rationality. d=n XOR l. Quotient u=(e,d,q) is encoded 4e+2d+q. ILE is x=0; superego is x=6.

A type-function truth-table mask is sum f(x)*2**x. System functions are normalized to f(0)=0. Their signs multiply by XOR. Signed pole masks are actual subsets and are not normalized when transported.

A position permutation is an array of eight images indexed 0..7 (position 0 means function 1). beta arrays act on aspects in the ILE row order:

Chi, BL, ChS, BE, BS, ChE, BI, ChL

The exact Cyrillic aspect names are in models.txt. Thus beta is written in reference-position coordinates; the companion Markdown converts it to aspect names. alpha acts directly on function positions.

A type permutation pi is an array of sixteen images indexed by normalized original type codes. All composition is rightmost first.

Table automorphism condition in reference coordinates:

P_pi(x) = beta P_x alpha^{-1}.

All such triples have alpha in N_S8(G), c in G and beta=P_c alpha. Their type action is pi(x)=c theta_alpha(x).

There are 1024 triples, but only 256 distinct type actions. Every effective type action has four triples above it. Stabilizer counts are therefore labeled explicitly as triple counts or effective counts.

The action on a normalized trait is f composed with pi^{-1}, followed by addition of its value at ILE. The action on a pole is direct set-image pi(P). Unoriented source feature partitions are normalized by the same rule on eight points.

D01..D16 are source type-system IDs. B1_1 etc. identify new type systems from the preceding study. Structure IDs 1,16,25,30 refer to the four fully compatible eight-point affine structures and are a separate numbering.

## Completeness and verification

All 40320 position permutations are tested for normalizing G. A verified generating triple of G suffices for the initial filter, and all 16 conjugates are then computed. The 1024 model automorphisms are complete by the normalizer parametrization proved in the report.

Abstract automorphisms are enumerated by all possible images of the three generators and checked against all products. Realizability is independently checked by preservation of the conjugacy class of the point stabilizer.

The normalizer and effective type-action sets are checked for group closure. Closure of all 24 systems is checked before assigning orbit names. Left and right affine counts are recalculated from the type action, separately from seed labels.

The four compatible affine structures are obtained by enumerating all 30 normalized feature families. Their orbits, stabilizers, linear images and translation kernels are calculated directly.

Every pole orbit has an explicit witness triple for every target from its representative. For these witnesses, the full relevant row/column cell equalities are checked. These equalities prove transport of arbitrary subset invariants, not only the recorded four-number profiles.

One representative wall profile is freshly calculated for each of the seven old-system orbits. All minimizing function/aspect sets are retained. Full invariants of new-system tetrachotomies and octochotomies are outside this stage.

The additional duality permits exchanging the function and aspect sorts. It is explicitly separated from sort-preserving automorphisms. All dual model equations are checked; the effective extended action is checked for closure under generators.

## Files

REPORT.md is the main Russian report. ORBIT_TABLES_AND_WITNESSES.md contains all level-specific orbit lists, type-system catalogues, explicit cyclic relabelings between representatives, pole representatives and the inversion map.

The report lists all JSON/CSV exports. Normalizer and model triple IDs are zero-based stable indices in their files. Witness references use these exact IDs. group_generators.json permits compact independent reconstruction of the two main permutation groups.

SHA256SUMS.txt covers every archived file except itself. The ZIP is tested, extracted into a separate directory, all four scripts are rerun and outputs and Markdown reports are compared byte-for-byte. The checksums also validate inputs and code.

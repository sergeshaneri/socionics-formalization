from pathlib import Path
import runpy,contextlib,io,json,itertools
root=Path(__file__).parent
with contextlib.redirect_stdout(io.StringIO()): b=runpy.run_path(str(root/'verify_base.py'))
rings=b['rings'];cells=b['cells'];coords=b['coords']
s=(root/'stimulus-source.md').read_text()
rows=[]
for line in s.splitlines():
 if line.startswith('|'):
  r=[x.strip() for x in line.strip('| ').split('|')]
  if len(r)==4 and all(x in coords for x in r):rows.append(r)
assert len(rows)==4 and len(set(sum(rows,[])))==16
xy={x:(i,j) for i,row in enumerate(rows) for j,x in enumerate(row)}
result={'coordinate_grid':rows,'rules':[],'torus_mesh':{'vertices':16,'edges':32,'faces':16,'euler_characteristic':0}}
for ring in rings:
 eps=coords[ring[0]]['eps'];data=[]
 for x in ring:
  y=b['succ'][x]
  a=[cells[x,t,3] for t in [1,-1]]
  mental=next(v for v in a if v['layer']==1)
  plus=next(v for v in a if v['sign']==1)
  # Define positive crossing as M(start)->V(end) passing OVER.
  eta_mental=1;eta_plus=plus['layer']
  assert eta_plus==-eps and mental['sign']==-eps
  dq=(xy[y][0]-xy[x][0])%4;dg=(xy[y][1]-xy[x][1])%4
  assert dq==eps%4 and dg in [0,2]
  data.append({'from':x,'to':y,'mental_over_aspect':mental['aspect'],'mental_sign':mental['sign'],'crossing_mental_rule':eta_mental,'crossing_plus_rule':eta_plus,'quadra_step':eps,'stimulus_step_mod4':dg})
 assert sum(d['stimulus_step_mod4']==2 for d in data)==2
 lifts=[]
 for choices in itertools.product([-2,2],repeat=2):
  it=iter(choices);steps=[next(it) if d['stimulus_step_mod4']==2 else 0 for d in data]
  assert sum(steps)%4==0
  lifts.append({'stimulus_steps':steps,'winding':[eps,sum(steps)//4]})
 result['rules'].append({'ring':ring,'eps':eps,'transitions':data,'mental_exponent':sum(d['crossing_mental_rule'] for d in data),'plus_exponent':sum(d['crossing_plus_rule'] for d in data),'minimal_coordinate_lifts':lifts})
assert [b['macro'][b['models']['ИЛЭ'][p-1][1]] for p in [3,4,1,2]]==[0,1,2,3]
(root/'results-new.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))

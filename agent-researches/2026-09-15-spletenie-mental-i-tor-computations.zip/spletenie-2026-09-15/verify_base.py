from pathlib import Path
import re,json,collections,itertools,hashlib
SRC=Path(__file__).parent/'source-tables.md'
s=SRC.read_text().replace('\\','').replace('*','')
rows=[[v.strip() for v in l.strip().strip('|').split('|')] for l in s.splitlines() if l.startswith('|')]
models={r[0]:r[1:] for r in rows if len(r)==9 and r[0] in ['ИЛЭ','СЭИ','ЭСЭ','ЛИИ','ЭИЭ','ЛСИ','СЛЭ','ИЭИ','ЛИЭ','ЭСИ','СЭЭ','ИЛИ','ИЭЭ','СЛИ','ЛСЭ','ЭИИ']}
head=next(r[1:] for r in rows if len(r)==17 and r[0]=='ТИМ')
traits={r[0]:dict(zip(head,map(int,r[1:]))) for r in rows if len(r)==17 and r[0] in models}
aspects={r[0]:r[1:] for r in rows if len(r)==9 and r[0] in models['ИЛЭ']}
functions={int(re.search(r'\((\d)\)',r[0])[1]):r[1:] for r in rows if len(r)==9 and re.search(r'\((\d)\)',r[0])}
assert len(models)==len(traits)==16 and len(aspects)==len(functions)==8
assert all(len(set(a))==8 for a in models.values())
pairs=[(3,5),(4,6),(1,7),(2,8)]
macro={'С':0,'Э':1,'И':2,'Л':3}
stat={'ЧС','БЭ','ЧИ','БЛ'}
pm=lambda b:2*b-1
coords={};cells={}
for x,a in models.items():
 m=[]
 for p,r in pairs:
  assert a[p-1][1]==a[r-1][1]
  m.append(macro[a[p-1][1]])
 c=m[0];eps=(m[1]-m[0])%4;eps=1 if eps==1 else -1
 assert m==[(c+eps*h)%4 for h in range(4)]
 t=traits[x];q=pm(t['Квестимность']);e=pm(t['Экстраверсия']);theta=pm(t['Статика'])
 assert eps==pm(t['Правые']) and e==eps*q and theta==e*((-1)**c)
 coords[x]={'eps':eps,'q':q,'c':c}
 for tau in [1,-1]:
  for h,ps in enumerate(pairs):
   p=next(p for p in ps if (a[p-1] in stat)==(tau==1));asp=a[p-1]
   v=1 if asp[0]=='Ч' else -1;sign=q*v;layer=1 if p<=4 else -1
   assert v==tau*((-1)**m[h])
   assert sign==q*tau*((-1)**(c+h))
   assert layer==eps*q*tau*((-1)**c)
   assert sign==eps*(1 if functions[p][1]=='+' else -1)
   cells[x,tau,h]={'aspect':asp,'sign':sign,'position':p,'layer':layer}
# Independently choose successors by aspects, sign, and layer, recording ambiguity.
candidates={};succ={}
for x in models:
 sets={}
 for mode in ['aspect','aspect_sign','aspect_layer','aspect_sign_layer','aspect_sign_eps']:
  found=[]
  for y in models:
   good=True
   for tau in [1,-1]:
    a=cells[x,tau,3];b=cells[y,tau,0]
    good &= a['aspect']==b['aspect']
    if 'sign' in mode:good &= a['sign']==b['sign']
    if 'layer' in mode:good &= a['layer']==-b['layer']
    if 'eps' in mode:good &= coords[x]['eps']==coords[y]['eps']
   if good:found.append(y)
  sets[mode]=found
 candidates[x]=sets
 assert len(sets['aspect_sign_layer'])==1
 succ[x]=sets['aspect_sign_layer'][0]
 assert sets['aspect_sign_eps']==[succ[x]]

def cycles(mapping):
 seen=set();out=[]
 for x in mapping:
  if x not in seen:
   cyc=[];y=x
   while y not in seen:seen.add(y);cyc.append(y);y=mapping[y]
   assert y==x
   out.append(cyc)
 return out
rings=cycles(succ)
T={(x,tau,h):((x,tau,h+1) if h<3 else (succ[x],tau,0)) for x,tau,h in cells}
flowcycles=cycles(T);assert sorted(map(len,flowcycles))==[16]*8
for x,tau,h in T:
 y=(x,tau,h)
 for _ in range(4):y=T[y]
 assert y==(succ[x],tau,h)
# Multiplicity and sign discrimination
for a in models['ИЛЭ']:
 for p in range(1,9):
  xs=[x for x in models if models[x][p-1]==a]
  assert len(xs)==2
  assert {coords[x]['q'] for x in xs}=={-1,1}
  assert {coords[x]['eps'] for x in xs}=={-1,1}
# Group of position permutations, right operand applied first
base=models['ИЛЭ'];perms={x:tuple(a.index(b) for b in base) for x,a in models.items()};names={v:k for k,v in perms.items()}
comp=lambda p,q:tuple(p[q[i]] for i in range(8))
identity=tuple(range(8))
power=lambda p,n:power(comp(p,p),n//2) if n and n%2==0 else (comp(p,power(p,n-1)) if n else identity)
assert all(comp(p,q) in names for p in perms.values() for q in perms.values())
O,R,K=(perms[x] for x in ['ЭИЭ','ЛИИ','ИЛИ'])
assert power(O,4)==power(R,2)==power(K,2)==identity
assert comp(R,comp(O,R))==power(O,3)
assert all(comp(K,p)==comp(p,K) for p in perms.values())
assert len({comp(power(O,i),comp(power(R,j),power(K,k))) for i in range(4) for j in range(2) for k in range(2)})==16
left={x:names[comp(O,p)] for x,p in perms.items()};right={x:names[comp(p,O)] for x,p in perms.items()}
# All Reinin columns which are characters of this noncommutative group
chars=[name for name in head if all(pm(traits[names[comp(perms[x],perms[y])]][name])==pm(traits[x][name])*pm(traits[y][name]) for x in models for y in models)]
# New: 2-valued edge voltages are exact differences of vertex labels.
voltage=[]
for cyc in flowcycles:
 zlayer=zsign=0
 for a in cyc:
  b=T[a];zlayer^=int(cells[a]['layer']!=cells[b]['layer']);zsign^=int(cells[a]['sign']!=cells[b]['sign'])
 assert zlayer==zsign==0
 voltage.append([zlayer,zsign])
# Slot-level rule for sign and local sign-layer duality checked above.
alternatives={}
for de,dq in itertools.product([1,-1],repeat=2):
 mapping={}
 for x in models:
  ys=[y for y in candidates[x]['aspect'] if coords[y]['eps']==de*coords[x]['eps'] and coords[y]['q']==dq*coords[x]['q']]
  assert len(ys)==1
  mapping[x]=ys[0]
 alternatives[f'eps_ratio={de},q_ratio={dq}']={'ILE_successor':mapping['ИЛЭ'],'cycle_lengths':list(map(len,cycles(mapping)))}
result={'alternative_rules':alternatives,'models_count':len(models),'traits_dimensions':[len(traits),len(head)],'aspect_table':[8,8],'function_table':[8,8],'cells':len(cells),'coordinates':coords,'candidate_counts':{mode:dict(collections.Counter(len(v[mode]) for v in candidates.values())) for mode in next(iter(candidates.values()))},'candidates':candidates,'rings':rings,'cycle_lengths':list(map(len,flowcycles)),'successor_equals_left':succ==left,'successor_equals_right':succ==right,'left_mismatches':{x:[succ[x],left[x]] for x in models if succ[x]!=left[x]},'right_mismatches':{x:[succ[x],right[x]] for x in models if succ[x]!=right[x]},'order_distribution':dict(collections.Counter(next(n for n in range(1,17) if power(p,n)==identity) for p in perms.values())),'characters':chars,'K_pairs':cycles({x:names[comp(K,p)] for x,p in perms.items()}),'voltage_totals':voltage,'sequences':[{'ring':ring,'tau':tau,'segments':[[cells[x,tau,h] for h in range(4)] for x in ring]} for ring in rings for tau in [1,-1]],'source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest()}
Path(__file__).with_name('results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['sequences','candidates','coordinates']},ensure_ascii=False,indent=2))

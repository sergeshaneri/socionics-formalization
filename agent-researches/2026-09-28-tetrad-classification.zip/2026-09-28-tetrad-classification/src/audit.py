exec((__import__('pathlib').Path(__file__).parent/'classify.py').read_text())
import re,sys
source=Path(sys.argv[1]) if len(sys.argv)>1 else D/'03-4-svezhak.md'
audit_name='corrected_formula_audit' if len(sys.argv)>1 else 'source_formula_audit'
base=['ЧИ','БЛ','ЧС','БЭ','БС','ЧЭ','БИ','ЧЛ']; aset=set(base)
section=None;B=None;current=None;audits=[];unparsed=[];headers=[]
for lineno,line in enumerate(source.read_text().splitlines(),1):
 match=re.match(r'^(\d+)\.\s+(?:#|\*\*)',line)
 if match:
  section=int(match[1]); B=None;current=None
 if line.lstrip().startswith('—'):
  ts=re.findall(r'(?<![А-Я])(?:'+ '|'.join(tg)+r')(?![А-Я])',line)
  if len(ts)==4:
   B=frozenset(tg[t] for t in ts); current=next((x for x in records if x['number']==section and frozenset(x['elements'])==B),None)
   headers.append({'line':lineno,'section':section,'types':ts,'matches_computed_tetrad':current is not None})
 if '→' not in line or '\\[' not in line:continue
 if B is None or current is None:
  unparsed.append({'line':lineno,'reason':'no matching tetrad header','text':line});continue
 lhs,rhs=line.split('→',1)
 ab=re.findall(r'\*\*([^*]+)\*\*',lhs);fb=re.findall(r'\*\*([^*]+)\*\*',rhs)
 try:
  aa=[tuple(base.index(a) for a in x.split()) for x in ab]
  ff=[tuple(int(f)-1 for f in x.split()) for x in fb]
  assert aa and ff and all(0<=f<8 for block in ff for f in block)
  if '~' in lhs:
   kind='partition';target=canonpart(ff)
   support=frozenset(g for g in ALL if canonpart([[p[g][a] for a in block] for block in aa])==target)
  elif '>' in lhs:
   kind='oriented_cycle';target=tuple(tuple(sorted(b)) for b in ff)
   rotations={target[i:]+target[:i] for i in range(len(target))}
   support=frozenset(g for g in ALL if tuple(tuple(sorted(p[g][a] for a in block)) for block in aa) in rotations)
  else:
   kind='inclusion';assert len(aa)==len(ff)==1
   support=frozenset(g for g in ALL if {p[g][a] for a in aa[0]}<=set(ff[0]))
  audits.append({'line':lineno,'tetrad':current['id'],'kind':kind,'holds_on_tetrad':B<=support,'selects_tetrad':B==support,'support_types':[gt[g] for g in sorted(support)],'counterexamples':[gt[g] for g in sorted(B-support)],'text':line})
 except (ValueError,AssertionError):unparsed.append({'line':lineno,'reason':'formula typography not parsed','text':line})
summary_a={'headers':len(headers),'matching_headers':sum(x['matches_computed_tetrad'] for x in headers),'parsed_formulas':len(audits),'valid_formulas':sum(x['holds_on_tetrad'] for x in audits),'failures':sum(not x['holds_on_tetrad'] for x in audits),'unparsed':len(unparsed),'kinds':dict(co.Counter(x['kind'] for x in audits))}
save(audit_name,{'summary':summary_a,'headers':headers,'formulas':audits,'unparsed':unparsed})
print('AUDIT',json.dumps(summary_a,ensure_ascii=False));print('FAILURES',[(x['line'],x['tetrad'],x['text'],x['counterexamples']) for x in audits if not x['holds_on_tetrad']])
conjunction=[]
for x in records:
 fs=[f for f in audits if f['tetrad']==x['id']]
 accepted=set.intersection(*(set(f['support_types']) for f in fs)) if fs else set(tg)
 conjunction.append({'tetrad':x['id'],'formula_count':len(fs),'accepted_types':sorted(accepted),'exact':accepted==set(x['types'])})
save(audit_name+'_conjunctions',conjunction)
print('EXACT_SOURCE_CONJUNCTIONS',sum(x['exact'] for x in conjunction))

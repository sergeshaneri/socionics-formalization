from pathlib import Path
import re,html
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_LEFT
R=Path(__file__).resolve().parents[1]
for name,fn in [('D','DejaVuSans.ttf'),('DB','DejaVuSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+fn))
pdfmetrics.registerFontFamily('D',normal='D',bold='DB',italic='D',boldItalic='DB')
styles={
'p':ParagraphStyle('p',fontName='D',fontSize=9.2,leading=13.6,spaceAfter=8),
'meta':ParagraphStyle('meta',fontName='D',fontSize=9.2,leading=13.6,spaceAfter=8,keepWithNext=True),
'h1':ParagraphStyle('h1',fontName='DB',fontSize=23,leading=30,spaceAfter=22),
'h2':ParagraphStyle('h2',fontName='DB',fontSize=14,leading=19,spaceBefore=15,spaceAfter=10,keepWithNext=True),
'h3':ParagraphStyle('h3',fontName='DB',fontSize=11,leading=16,spaceBefore=10,spaceAfter=7,keepWithNext=True),
't':ParagraphStyle('t',fontName='D',fontSize=7.5,leading=10.5,wordWrap='CJK'),
}
def text(x):
 x=html.escape(x)
 x=re.sub(r'\*\*(.*?)\*\*',r'<b>\1</b>',x)
 return x.replace('–','-').replace('—','-')
parts=[];ls=(R/'2026-09-28-tetrad-classification.md').read_text().splitlines();i=0
while i<len(ls):
 l=ls[i].strip();i+=1
 if not l:continue
 if l.startswith('# '):
  parts.extend([Spacer(1,90),Paragraph(text(l[2:]),styles['h1']),Paragraph('28 сентября 2026 года',styles['h2']),Paragraph('35 тетрахотомий • 140 тетрад<br/>Модель А • G = D₈ × C₂ • 8T9',styles['p']),Spacer(1,30),Paragraph('Формулы, подгруппы, стабилизаторы и классы эквивалентности. Полный каталог и воспроизводимые вычисления.',styles['p']),PageBreak()]);continue
 if l.startswith('## '):
  if l.startswith('## 13.'):parts.append(PageBreak())
  parts.append(Paragraph(text(l[3:]),styles['h2']));continue
 if l.startswith('### '):parts.append(Paragraph(text(l[4:]),styles['h3']));continue
 if l.startswith('| '):
  rows=[l]
  while i<len(ls) and ls[i].startswith('| '):rows.append(ls[i]);i+=1
  rows=[r for r in rows if not re.match(r'^\|[\s|:-]+\|$',r)]
  data=[[Paragraph(text(c.strip()),styles['t']) for c in r.strip('|').split('|')] for r in rows]
  n=len(data[0]);width=483
  if n==7:ws=[24,138,36,48,48,48,45]
  elif n==6:ws=[38,175,47,47,90,46]
  elif n==5:ws=[140,57,92,140,54]
  elif n==4:ws=[146,65,83,189]
  elif n==3:ws=[25,229,229]
  else:ws=[width/n]*n
  if sum(ws)!=width:ws=[x*width/sum(ws) for x in ws]
  t=Table(data,colWidths=ws,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e8edf2')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#617184')),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#d5dce2')),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]));parts.extend([t,Spacer(1,10)]);continue
 parts.append(Paragraph(text(l),styles['meta'] if l.startswith('**T') else styles['p']))
def footer(c,d):
 c.setFont('D',8);c.setFillColor(colors.HexColor('#647080'));c.drawString(56,30,'Тетрахотомии и модель А · 28.09.2026');c.drawRightString(539,30,str(d.page))
doc=SimpleDocTemplate(str(R/'2026-09-28-tetrad-classification.pdf'),pagesize=(595.28,841.89),rightMargin=56,leftMargin=56,topMargin=48,bottomMargin=50,title='Классификация тетрахотомий и тетрад в модели А',author='Исследовательский проект: мат')
doc.build(parts,onFirstPage=footer,onLaterPages=footer)

from pathlib import Path
import json,itertools as it,collections as co,csv
R=Path(__file__).resolve().parents[1]; D=R/'data'; O=R/'results'; O.mkdir(exist_ok=True)
def load(n):return json.loads((D/(n+'.json')).read_text())
def save(n,x):(O/(n+'.json')).write_text(json.dumps(x,ensure_ascii=False,indent=2))
prs=load('permutations'); p=[tuple(v-1 for v in r['images']) for r in prs]; names=[r['name'] for r in prs]
m=load('multiplication'); mt=m['table']; iv=m['inverses']; sg=load('subgroups'); sid={frozenset(s['elements']):s['id'] for s in sg}; sb={s['id']:s for s in sg}
tg={t:x['id'] for t,x in load('type_to_relation').items()}; gt={g:t for t,g in tg.items()}; tet=load('tetrachotomies'); ALL=frozenset(range(16))
assert all(tuple(p[a][p[b][i]] for i in range(8))==p[mt[a][b]] for a in ALL for b in ALL)
def clos(s):
 h={0};old=None
 while old!=h:
  old=set(h);h|={mt[a][b] for a in old for b in s}
 return frozenset(h)
def left(B,a):return frozenset(mt[a][b] for b in B)
def right(B,a):return frozenset(mt[b][a] for b in B)
def canonpart(bs):return tuple(sorted(tuple(sorted(b)) for b in bs))
def ltranspart(bs,a):return canonpart([left(b,a) for b in bs])
classes={1:[7],2:[12,19,28,33],3:[1,3,4,6,13,18,29,32],4:[8,14,20,21],5:[9,10,11,15,16,17,24,25,30,31,34,35],6:[2,5,22,23,26,27]}
fc={n:c for c,ns in classes.items() for n in ns}
# Exhaustive inclusion language psi(A) subset F, all nonempty proper subsets.
subs=list(range(1,255)); bits=lambda v:[i for i in range(8) if v>>i&1]
ims={a:[sum(1<<q[i] for i in bits(a)) for q in p] for a in subs}
by_support=co.defaultdict(list)
for a in subs:
 for f in subs:
  if a.bit_count()>f.bit_count():continue
  mask=sum(1<<g for g,v in enumerate(ims[a]) if v&~f==0)
  by_support[mask].append([a,f])
supportsets={mask:frozenset(g for g in ALL if mask>>g&1) for mask in by_support}
# Normalizer in S8, represented as automorphisms on G.
idx={q:g for g,q in enumerate(p)}
gens=sb['H34']['generators']; norms=[]; autom=[]
for q in it.permutations(range(8)):
 def conj(g):
  r=[0]*8
  for i in range(8):r[q[i]]=q[p[g][i]]
  return tuple(r)
 if all(conj(g) in idx for g in gens):
  norms.append(q); autom.append(tuple(idx[conj(g)] for g in ALL))
autom=sorted(set(autom));save('normalizer',{'order':len(norms),'induced_automorphisms':autom,'permutations_1based':[[v+1 for v in q] for q in norms]})
# The transported character table supplies every dichotomy and verifies multiplication.
lines=(D/'09-markdown-1-.md').read_text().splitlines(); table=[]; reading=False
for line in lines:
 if line.startswith('| ТИМ | Существование'):reading=True
 elif reading and not line.startswith('|'):break
 if reading:table.append([x.strip().replace('\\','').replace('*','') for x in line.strip().strip('|').split('|')])
traits={r[0]:list(map(int,r[1:])) for r in table[2:] if r[0]}
chars=[[2*traits[gt[g]][i]-1 for g in ALL] for i in range(16)]
assert len(traits)==16 and all(sum(a*b for a,b in zip(x,y))==(16 if i==j else 0) for i,x in enumerate(chars) for j,y in enumerate(chars))
hom=[i for i,c in enumerate(chars) if all(c[mt[a][b]]==c[a]*c[b] for a in ALL for b in ALL)]
# Exact tetrad profiles.
records=[]
for row in tet:
 for bi,b in enumerate(row['blocks'],1):
  B=frozenset(tg[t] for t in b['types']); mask=sum(1<<g for g in B)
  l=frozenset(a for a in ALL if left(B,a)==B);r=frozenset(a for a in ALL if right(B,a)==B)
  H=clos({mt[a][iv[z]] for a in B for z in B});assert sid[H]==b['generated_subgroup']
  forms=by_support.get(mask,[])
  minforms=[f for f in forms if sum(v.bit_count() for v in f)==min((sum(v.bit_count() for v in x) for x in forms),default=99)]
  inclusion_closure=frozenset.intersection(*(s for s in supportsets.values() if B<=s))
  # Correlation support on ordered k-tuples: reconstruct B by all projections of order k.
  projection_sizes=[];witness=None
  for k in range(1,9):
   candidates=set(ALL)
   for coords in it.combinations(range(8),k):
    observed={tuple(p[g][i] for i in coords) for g in B}
    accepted={g for g in ALL if tuple(p[g][i] for i in coords) in observed}
    candidates &=accepted
    if accepted==B and witness is None:witness={'coordinates_1based':[x+1 for x in coords],'allowed_tuples_1based':[list(v+1 for v in x) for x in sorted(observed)]}
   projection_sizes.append(len(candidates))
   if candidates==B:break
  # complete unary incidence matrix / joint support retained for reproducibility
  inc=[[sum(p[g][a]==f for g in B) for f in range(8)] for a in range(8)]
  canon=min(tuple(sorted(mt[mt[a][x]][z] for x in B)) for a in ALL for z in ALL)
  normcanon=min(tuple(sorted(mt[a][u[x]] for x in B)) for a in ALL for u in autom)
  record=dict(id=f"T{row['number']:02d}.{bi}",number=row['number'],formula_class=fc[row['number']],types=b['types'],elements=sorted(B),closure=sid[H],closure_type=sb[sid[H]]['abstract_type'],left_stabilizer=sid[l],right_stabilizer=sid[r],left_stabilizer_order=len(l),right_stabilizer_order=len(r),closed_relative=b['closed'],exact_inclusions=forms,minimal_size_inclusions=minforms,inclusion_closure=sorted(inclusion_closure),projection_closure_sizes=projection_sizes,minimal_correlation_order=len(projection_sizes),single_projection_witness=witness,incidence=inc,left_right_canonical=canon,normalizer_affine_canonical=normcanon,internal_relations=b['all_internal_relations'],anchored_relations=b['anchored_relations'],signs=b['signs'])
  records.append(record)
for key in ['left_right_canonical','normalizer_affine_canonical']:
 reps=sorted(set(tuple(x[key]) for x in records))
 for x in records:x[key+'_class']=reps.index(tuple(x[key]))+1
partitions=[]
for row in tet:
 bs=[frozenset(tg[t] for t in b['types']) for b in row['blocks']]; cp=canonpart(bs)
 l=[g for g in ALL if ltranspart(bs,g)==cp];r=[g for g in ALL if canonpart([right(b,g) for b in bs])==cp]
 kernel=[g for g in l if all(left(b,g)==b for b in bs)]
 derived=[]
 for g in l:derived.append([bs.index(left(b,g)) for b in bs])
 assert len(set(tuple(q) for q in derived))*len(kernel)==len(l)
 partitions.append(dict(number=row['number'],traits=row['traits'],formula_class=fc[row['number']],joint_closure=row['all_blocks_generated_subgroup'],left_partition_stabilizer=sid[frozenset(l)],right_partition_stabilizer=sid[frozenset(r)],left_partition_kernel=sid[frozenset(kernel)],left_block_action=derived,normalizer_affine_canonical=min(canonpart([frozenset(mt[a][u[x]] for x in b) for b in bs]) for a in ALL for u in autom)))
reps=sorted(set(x['normalizer_affine_canonical'] for x in partitions))
for x in partitions:x['normalizer_affine_class']=reps.index(x['normalizer_affine_canonical'])+1
# Verify full 35 = every two-character partition (three nonidentity characters per partition).
allpart=set()
for i,j in it.combinations(range(1,16),2):
 bs=co.defaultdict(list)
 for g in ALL:bs[chars[i][g],chars[j][g]].append(g)
 allpart.add(canonpart(bs.values()))
assert allpart=={canonpart([x['elements'] for x in records if x['number']==n]) for n in range(1,36)}
# Dichotomy profiles and exact inclusions, in the same finite language.
dich=[]
for i in range(1,16):
 poles=[]
 for sign in [1,-1]:
  B=frozenset(g for g in ALL if chars[i][g]==sign); H=clos({mt[a][iv[z]] for a in B for z in B}); mask=sum(1<<g for g in B)
  poles.append(dict(sign=sign,elements=sorted(B),closure=sid[H],left_stabilizer=sid[frozenset(a for a in ALL if left(B,a)==B)],exact_inclusions=by_support.get(mask,[])))
 dich.append(dict(name=table[0][i+1],homomorphism=i in hom,poles=poles))
save('tetrads',records);save('tetrachotomies',partitions);save('dichotomies',dich)
summary={'tetrads':len(records),'partitions':len(partitions),'normalizer_order':len(norms),'normalizer_automorphisms':len(autom),'left_right_tetrad_classes':len(set(x['left_right_canonical_class'] for x in records)),'normalizer_affine_tetrad_classes':len(set(x['normalizer_affine_canonical_class'] for x in records)),'normalizer_affine_partition_classes':len(reps),'character_homomorphisms':[table[0][i+1] for i in hom], 'profiles':{str(c):{'numbers':classes[c],'closure_types':dict(co.Counter(x['closure_type'] for x in records if x['formula_class']==c)),'left_stabilizer_orders':dict(co.Counter(x['left_stabilizer_order'] for x in records if x['formula_class']==c)),'right_stabilizer_orders':dict(co.Counter(x['right_stabilizer_order'] for x in records if x['formula_class']==c)),'correlation_orders':dict(co.Counter(x['minimal_correlation_order'] for x in records if x['formula_class']==c)),'exact_inclusion_count':dict(co.Counter(len(x['exact_inclusions']) for x in records if x['formula_class']==c)),'inclusion_closure_size':dict(co.Counter(len(x['inclusion_closure']) for x in records if x['formula_class']==c))} for c in classes}}
save('summary',summary)
print(json.dumps(summary,ensure_ascii=False,indent=2))
# All invariant partitions of the eight functions for every subgroup.
def setparts(xs):
 if not xs:yield ();return
 x,*rest=xs
 for part in setparts(rest):
  yield ((x,),)+part
  for j in range(len(part)):
   yield part[:j]+(tuple(sorted((x,)+part[j])),)+part[j+1:]
parts=sorted(set(canonpart(x) for x in setparts(list(range(8)))))
assert len(parts)==4140
blocks=[]
for s in sg:
 stable=[]
 for part in parts:
  if len(part) in [1,8]:continue
  if all(canonpart([[p[g][x] for x in b] for b in part])==part for g in s['generators']):stable.append([[x+1 for x in b] for b in part])
 blocks.append({'subgroup':s['id'],'invariant_partitions':stable})
save('invariant_partitions',blocks)
# Closure of the studied families under each declared equivalence group.
family={tuple(x['elements']) for x in records}; pfamily={canonpart([x['elements'] for x in records if x['number']==n]) for n in range(1,36)}
summary['normalizer_affine_preserves_tetrad_family']=all(tuple(sorted(mt[a][u[x]] for x in b)) in family for b in family for a in ALL for u in autom)
summary['normalizer_affine_preserves_partition_family']=all(canonpart([frozenset(mt[a][u[x]] for x in b) for b in part]) in pfamily for part in pfamily for a in ALL for u in autom)
# Minimal number of inclusion conjuncts, using exact support bitmasks, with certificates.
for x in records:
 B=frozenset(x['elements']);target=sum(1<<g for g in B)
 candidates=[(mask,fs[0]) for mask,fs in by_support.items() if mask&target==target and mask!=65535]
 reached={65535:[]};front=[65535]
 while front and target not in reached:
  nxt=[]
  for mask in front:
   for support,f in candidates:
    new=mask&support
    if new not in reached:reached[new]=reached[mask]+[f];nxt.append(new)
  front=nxt
 x['minimal_inclusion_conjunction']=reached.get(target)
summary['minimal_inclusion_conjunct_counts']=dict(co.Counter(str(len(x['minimal_inclusion_conjunction'])) if x['minimal_inclusion_conjunction'] is not None else 'impossible' for x in records))
save('tetrads',records);save('summary',summary)
print('ADDITIONS',json.dumps({k:v for k,v in summary.items() if k not in ['profiles']},ensure_ascii=False))
# Export readable full rows.
for filename,rs,keys in [('tetrads',records,['id','number','formula_class','types','closure','closure_type','left_stabilizer','right_stabilizer','minimal_correlation_order','normalizer_affine_canonical_class','minimal_inclusion_conjunction']),('tetrachotomies',partitions,['number','traits','formula_class','joint_closure','left_partition_stabilizer','right_partition_stabilizer','left_partition_kernel','normalizer_affine_class'])]:
 with (O/(filename+'.csv')).open('w') as f:
  w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(rs)

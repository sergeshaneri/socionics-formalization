import json,re
from pathlib import Path
R=Path(__file__).resolve().parents[1];D=R/'data';O=R/'results'
a=json.loads((O/'source_formula_audit.json').read_text()); prs=json.loads((D/'permutations.json').read_text()); p=[tuple(v-1 for v in x['images']) for x in prs];tg={t:x['id'] for t,x in json.loads((D/'type_to_relation.json').read_text()).items()};gt={g:t for t,g in tg.items()};base=['ЧИ','БЛ','ЧС','БЭ','БС','ЧЭ','БИ','ЧЛ'];lines=(D/'03-4-svezhak.md').read_text().splitlines(); fixes=[]
canon=lambda blocks:tuple(sorted(tuple(sorted(b)) for b in blocks))
for h in a['headers']:
 if h['matches_computed_tetrad']:continue
 selected=set(range(16));n=0
 for line in lines[h['line']:]:
  if line.startswith('—') or re.match(r'^\d+\.\s',line):break
  if '→' not in line or '\\[' not in line:continue
  lhs,rhs=line.split('→',1);aa=[tuple(base.index(v) for v in b.split()) for b in re.findall(r'\*\*([^*]+)\*\*',lhs)];ff=[tuple(int(v)-1 for v in b.split()) for b in re.findall(r'\*\*([^*]+)\*\*',rhs)]
  if '~' in lhs:s={g for g in range(16) if canon([[p[g][i] for i in b] for b in aa])==canon(ff)}
  elif '>' in lhs:
   target=tuple(tuple(sorted(b)) for b in ff);rot={target[i:]+target[:i] for i in range(len(target))};s={g for g in range(16) if tuple(tuple(sorted(p[g][i] for i in b)) for b in aa) in rot}
  else:s={g for g in range(16) if {p[g][i] for i in aa[0]}<=set(ff[0])}
  selected &= s;n+=1
 fixes.append({**h,'formula_count':n,'joint_formula_support':[gt[g] for g in sorted(selected)]})
(O/'source_header_corrections.json').write_text(json.dumps(fixes,ensure_ascii=False,indent=2));print(json.dumps(fixes,ensure_ascii=False,indent=2))
# Corrected derivative, preserving original source separately.
corrected=list(lines);changelog=[]
for f in fixes:
 old=corrected[f['line']-1];oldtypes=set(f['types']);newtypes=set(f['joint_formula_support']);removed=list(oldtypes-newtypes);added=list(newtypes-oldtypes)
 assert len(removed)==len(added)==1
 corrected[f['line']-1]=old.replace(removed[0],added[0]);changelog.append({'line':f['line'],'old':old,'new':corrected[f['line']-1]})
for x in a['formulas']:
 if x['holds_on_tetrad']:continue
 old=corrected[x['line']-1]
 if x['tetrad'].startswith('T28'):
  new=old.replace('ЧЛ БЭ','TEMP').replace('БЛ ЧЭ','ЧЛ БЭ').replace('TEMP','БЛ ЧЭ')
  new=new.replace('дельта гамма','TEMP').replace('бета альфа','дельта гамма').replace('TEMP','бета альфа')
 elif x['tetrad'].startswith('T30'):
  new=old.replace('ЧЛ БЛ','TEMP').replace('ЧЭ БЭ','ЧЛ БЛ').replace('TEMP','ЧЭ БЭ')
  for j in range(x['line']-2,max(0,x['line']-7),-1):
   if 'Последовательность' in corrected[j]:
    prior=corrected[j];corrected[j]=prior.replace('Процесса','TEMP').replace('Результата','Процесса').replace('TEMP','Результата');changelog.append({'line':j+1,'old':prior,'new':corrected[j]});break
 else:raise AssertionError(x)
 corrected[x['line']-1]=new;changelog.append({'line':x['line'],'old':old,'new':new})
(O/'4-svezhak-corrected.md').write_text('\n'.join(corrected)+'\n');(O/'source_corrections.json').write_text(json.dumps(changelog,ensure_ascii=False,indent=2))
# Full relation graphs and pair orbitals complement subgroup profiles.
mt=json.loads((D/'multiplication.json').read_text())['table'];iv=json.loads((D/'multiplication.json').read_text())['inverses'];ts=json.loads((O/'tetrads.json').read_text());sg=json.loads((D/'subgroups.json').read_text())
(O/'relation_graphs.json').write_text(json.dumps([{'tetrad':x['id'],'vertices':x['types'],'relation_matrix':[[mt[tg[u]][iv[tg[t]]] for u in x['types']] for t in x['types']]} for x in ts],ensure_ascii=False,indent=2))
orb=[]
for h in sg:
 rem=set((i,j) for i in range(8) for j in range(8));obs=[]
 while rem:
  i,j=min(rem);o={(p[g][i],p[g][j]) for g in h['elements']};rem-=o;obs.append([list((i+1,j+1)) for i,j in sorted(o)])
 orb.append({'subgroup':h['id'],'ordered_pair_orbits':obs})
(O/'pair_orbits.json').write_text(json.dumps(orb,ensure_ascii=False,indent=2))

#!/usr/bin/env python3
"""Exhaustive 8T9 / Reinin calculations from the bundled Markdown tables.

Standard library only. Permutations act on 1..8; composition p*q means
apply q first, then p. Trait bits are 0 at ILE and 1 at the opposite pole.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DEFAULT_SOURCE = ROOT / "source" / "markdown_tables.md"
IDENTITY = tuple(range(1, 9))
COORD_NAMES = ("Экстраверсия", "Иррациональность", "Рассудительность", "Демократизм")


def clean(value: str) -> str:
    return value.strip().replace("\\", "").replace("*", "")


def cells(line: str) -> list[str]:
    return [clean(x) for x in line.strip().strip("|").split("|")]


def table(lines: list[str], prefix: str) -> tuple[list[str], list[tuple[str, list[str]]]]:
    found = [i for i, line in enumerate(lines) if line.startswith(prefix)]
    assert len(found) == 1, (prefix, found)
    i = found[0]
    header = cells(lines[i])
    rows = []
    for line in lines[i + 2 :]:
        if not line.startswith("|"):
            break
        row = cells(line)
        if row[0]:
            assert len(row) == len(header), (prefix, row)
            rows.append((row[0], row[1:]))
    return header, rows


def compose(p: tuple[int, ...], q: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(p[q[i] - 1] for i in range(8))


def add(x: tuple[int, ...], y: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(a ^ b for a, b in zip(x, y))


def star(x: tuple[int, ...], y: tuple[int, ...]) -> tuple[int, ...]:
    e, i, j, d = x
    ep, ip, jp, dp = y
    return (e ^ ep, i ^ ip, j ^ jp ^ (d & ip), d ^ dp)


def ring_product(x: tuple[int, ...], y: tuple[int, ...]) -> tuple[int, ...]:
    return (0, 0, x[3] & y[1], 0)


def orbits(perms: list[tuple[int, ...]]) -> list[list[int]]:
    unseen = set(range(1, 9))
    result = []
    while unseen:
        p = min(unseen)
        orb = sorted({g[p - 1] for g in perms})
        result.append(orb)
        unseen.difference_update(orb)
    return result


def order(p: tuple[int, ...]) -> int:
    q = IDENTITY
    for n in range(1, 17):
        q = compose(q, p)
        if q == IDENTITY:
            return n
    raise AssertionError("element order exceeds 16")


def sign(p: tuple[int, ...]) -> int:
    return sum(p[i] > p[j] for i in range(8) for j in range(i + 1, 8)) % 2


def from_cycles(*cycles: tuple[int, ...]) -> tuple[int, ...]:
    p = list(IDENTITY)
    for cycle in cycles:
        for i, value in enumerate(cycle):
            p[value - 1] = cycle[(i + 1) % len(cycle)]
    return tuple(p)


def subgroup(generators: list[tuple[int, ...]]) -> set[tuple[int, ...]]:
    seen = {IDENTITY}
    frontier = [IDENTITY]
    while frontier:
        p = frontier.pop()
        for generator in generators:
            candidate = compose(p, generator)
            if candidate not in seen:
                seen.add(candidate)
                frontier.append(candidate)
    return seen


def block_systems(perms: list[tuple[int, ...]], size: int) -> list[list[list[int]]]:
    result = []
    for tail in itertools.combinations(range(2, 9), size - 1):
        block = {1, *tail}
        if all(
            (image := {p[x - 1] for x in block}) == block or image.isdisjoint(block)
            for p in perms
        ):
            system = sorted({tuple(sorted(p[x - 1] for x in block)) for p in perms})
            assert len(system) == 8 // size
            result.append([list(b) for b in system])
    return result


def main(source: Path, output: Path) -> None:
    raw = source.read_bytes()
    lines = raw.decode("utf-8").splitlines()
    h_models, models_rows = table(lines, "| ТИМ | 1 (Прогр.)")
    h_traits, trait_rows = table(lines, "| ТИМ | Существование")
    h_aspect, aspect_rows = table(lines, "| | Сущ | Верт | дт/бт")
    h_function, function_rows = table(lines, "| | Сущ | Верт | Оц/Сит")
    h_ito, ito_rows = table(lines, "| ИТО |")

    models = dict(models_rows)
    traits = {name: tuple(map(int, row)) for name, row in trait_rows}
    aspects = dict(aspect_rows)
    function_rows = dict(function_rows)
    named_order = [int(x.split()[0]) for x in h_ito[1:]]
    permutations = {
        name: tuple(int(row[named_order.index(i)]) for i in range(1, 9))
        for name, row in ito_rows
    }
    assert len(models) == len(traits) == len(permutations) == 16
    assert all(set(row) == set(models["ИЛЭ"]) for row in models.values())
    assert len(set(permutations.values())) == 16
    perm_to_name = {p: name for name, p in permutations.items()}
    assert IDENTITY in perm_to_name
    assert all(compose(p, q) in perm_to_name for p in permutations.values() for q in permutations.values())

    # GAP TransGrp source data/trans8.grp, ninth entry (8T9). The
    # conjugator was found by enumeration and is then checked exactly.
    gap_generators = [
        from_cycles((1, 8), (2, 3), (4, 5), (6, 7)),
        from_cycles((1, 3), (2, 8), (4, 6), (5, 7)),
        from_cycles((1, 5), (2, 6), (3, 7), (4, 8)),
        from_cycles((4, 5), (6, 7)),
    ]
    canonical_8t9 = subgroup(gap_generators)
    conjugator = (1, 4, 8, 5, 2, 7, 3, 6)
    conjugator_inverse = tuple(conjugator.index(i) + 1 for i in range(1, 9))
    assert len(canonical_8t9) == 16
    assert {compose(compose(conjugator, p), conjugator_inverse)
            for p in permutations.values()} == canonical_8t9

    # The ITO row g maps each reference position to the position of its
    # reference aspect in the corresponding type's Model A.
    type_to_relation = {}
    for typ, row in models.items():
        p = tuple(row.index(models["ИЛЭ"][i]) + 1 for i in range(8))
        assert p in perm_to_name, typ
        type_to_relation[typ] = perm_to_name[p]
    assert len(set(type_to_relation.values())) == 16
    relation_to_type = {rel: typ for typ, rel in type_to_relation.items()}

    trait_labels = h_traits[1:]
    normalized = {
        typ: tuple(traits["ИЛЭ"][j] ^ values[j] for j in range(16))
        for typ, values in traits.items()
    }
    assert all(x == 1 for x in traits["ИЛЭ"])
    assert all(normalized[typ][0] == 0 for typ in models)
    tbits = {
        typ: tuple(normalized[typ][trait_labels.index(name)] for name in COORD_NAMES)
        for typ in models
    }
    assert len(set(tbits.values())) == 16
    all_bits = list(itertools.product((0, 1), repeat=4))
    bits_to_type = {bits: typ for typ, bits in tbits.items()}
    assert set(bits_to_type) == set(all_bits)
    bits_to_perm = {bits: permutations[type_to_relation[bits_to_type[bits]]] for bits in all_bits}
    perm_to_bits = {p: bits for bits, p in bits_to_perm.items()}
    assert permutations["Дуальность"] == bits_to_perm[(1, 0, 0, 0)]
    assert permutations["Активация"] == bits_to_perm[(0, 1, 0, 0)]
    assert permutations["Суперэго"] == bits_to_perm[(0, 0, 1, 0)]
    assert permutations["Родственные"] == bits_to_perm[(0, 0, 0, 1)]

    for x, y in itertools.product(all_bits, repeat=2):
        assert compose(bits_to_perm[x], bits_to_perm[y]) == bits_to_perm[star(x, y)]
        assert star(x, y) == add(add(x, y), ring_product(x, y))
    for x, y, z in itertools.product(all_bits, repeat=3):
        assert star(star(x, y), z) == star(x, star(y, z))
        assert ring_product(ring_product(x, y), z) == (0, 0, 0, 0)
        assert ring_product(x, ring_product(y, z)) == (0, 0, 0, 0)
        assert ring_product(x, add(y, z)) == add(ring_product(x, y), ring_product(x, z))
        assert ring_product(add(x, y), z) == add(ring_product(x, z), ring_product(y, z))

    # The associated set-theoretic Yang--Baxter map of this brace.
    def yb(x: tuple[int, ...], y: tuple[int, ...]) -> tuple[tuple[int, ...], tuple[int, ...]]:
        return add(y, ring_product(x, y)), add(x, ring_product(y, x))

    for x, y in itertools.product(all_bits, repeat=2):
        assert yb(*yb(x, y)) == (x, y)
    for x, y, z in itertools.product(all_bits, repeat=3):
        u, v = yb(x, y)
        v, w = yb(v, z)
        u, v = yb(u, v)
        lhs = (u, v, w)
        v, w = yb(y, z)
        u, v = yb(x, v)
        v, w = yb(v, w)
        assert lhs == (u, v, w)

    # Signs of the chosen Hadamard coordinates: + maps to 0, - maps to 1.
    fcol = ("Верт", "Оц/Сит", "Вб/Лб")
    acol = ("Верт", "дт/бт", "аф/гм")
    fcoords = {}
    for label, row in function_rows.items():
        number = int(label.rsplit("(", 1)[1].rstrip(")"))
        fcoords[number] = tuple(int(row[h_function.index(name) - 1] == "-") for name in fcol)
    acoords = {
        aspect: tuple(int(row[h_aspect.index(name) - 1] == "-") for name in acol)
        for aspect, row in aspects.items()
    }
    assert len(set(fcoords.values())) == len(set(acoords.values())) == 8
    coord_to_position = {v: p for p, v in fcoords.items()}
    assert all(acoords[aspect] == fcoords[i + 1] for i, aspect in enumerate(models["ИЛЭ"]))

    def act(bits: tuple[int, ...], f: tuple[int, ...]) -> tuple[int, ...]:
        e, i, j, d = bits
        a, b, c = f
        return (a ^ e, b ^ i ^ j ^ (d & (b ^ c)), c ^ j ^ (d & (b ^ c)))

    for bits, perm in bits_to_perm.items():
        for p in range(1, 9):
            assert act(bits, fcoords[p]) == fcoords[perm[p - 1]]
    for typ, row in models.items():
        for p, aspect in enumerate(row, start=1):
            assert act(tbits[typ], acoords[aspect]) == fcoords[p]

    # Recover all 15 Reinin linear forms on the additive E16 coordinates.
    reinin_forms = {}
    for j, label in enumerate(trait_labels):
        candidates = [
            mask for mask in range(16)
            if all((sum((mask >> k & 1) * bits[k] for k in range(4)) % 2)
                   == normalized[bits_to_type[bits]][j] for bits in all_bits)
        ]
        assert len(candidates) == 1, label
        reinin_forms[label] = candidates[0]
    assert set(reinin_forms.values()) == set(range(16))
    assert reinin_forms["Существование"] == 0
    assert all(sum(row) == 8 for name, row in ((label, [normalized[typ][j] for typ in models])
                                            for j, label in enumerate(trait_labels)) if name != "Существование")

    char_rows = []
    for label, mask in reinin_forms.items():
        if label == "Существование":
            continue
        fn = lambda x: sum((mask >> k & 1) * x[k] for k in range(4)) % 2
        is_character = all(fn(star(x, y)) == (fn(x) ^ fn(y)) for x, y in itertools.product(all_bits, repeat=2))
        assert is_character == ((mask & 4) == 0)
        kernel = [x for x in all_bits if fn(x) == 0]
        abelian = all(star(x, y) == star(y, x) for x, y in itertools.product(kernel, repeat=2)) if is_character else None
        count_order4 = sum(star(x, x) != (0, 0, 0, 0) for x in kernel) if is_character else None
        kind = ("C2^3" if count_order4 == 0 else "C4 x C2" if abelian else "D4") if is_character else None
        char_rows.append({
            "trait": label,
            "mask_EIJD": format(mask, "04b")[::-1],
            "group_character": is_character,
            "descends_to_8_functions": is_character and (mask & 8) == 0,
            "kernel_structure": kind,
            "kernel_order4_elements": count_order4,
        })

    # On position p, I(p) is the parity of its number; E(p) is the
    # parity of the conventional Model A dimensionality (4,3,2,1,1,2,3,4).
    position_parity = {p: (p + 1) % 2 for p in range(1, 9)}
    dimensions = {p: v for p, v in enumerate((4, 3, 2, 1, 1, 2, 3, 4), start=1)}
    assert all(position_parity[p] == fcoords[p][1] ^ fcoords[p][2] for p in range(1, 9))
    assert all(dimensions[p] % 2 == fcoords[p][0] for p in range(1, 9))
    assert all(sign(p) == 0 for p in permutations.values())

    blocks2 = block_systems(list(permutations.values()), 2)
    blocks4 = block_systems(list(permutations.values()), 4)
    assert len(blocks2) == len(blocks4) == 3
    expected4 = [
        [[1, 2, 3, 4], [5, 6, 7, 8]],
        [[1, 3, 5, 7], [2, 4, 6, 8]],
        [[1, 3, 6, 8], [2, 4, 5, 7]],
    ]
    assert blocks4 == sorted(expected4) or sorted(blocks4) == sorted(expected4)
    center = sorted(name for name, p in permutations.items()
                    if all(compose(p, q) == compose(q, p) for q in permutations.values()))
    assert set(center) == {"Тождество", "Дуальность", "Суперэго", "ПП"}
    commutators = set()
    for x, y in itertools.product(all_bits, repeat=2):
        commutators.add((0, 0, (x[3] & y[1]) ^ (y[3] & x[1]), 0))
    assert {type_to_relation[bits_to_type[x]] for x in commutators} == {"Тождество", "Суперэго"}

    summary = {
        "source_sha256": hashlib.sha256(raw).hexdigest(),
        "source_size_bytes": len(raw),
        "conjugator_to_gap_8t9": list(conjugator),
        "conventions": {"composition": "p after q", "coordinate_order": list(COORD_NAMES),
                        "trait_bit": "0 at ILE; 1 at opposite pole", "hadamard_sign": "+=0, -=1"},
        "exhaustive_checks": {"group_compositions": 256, "associativity_triples": 4096,
                              "function_actions": 128, "aspect_to_function_cells": 128,
                              "ring_distributivity_triples": 4096, "yang_baxter_triples": 4096},
        "type_to_relation": type_to_relation,
        "coordinate_to_type": {"".join(map(str, bits)): bits_to_type[bits] for bits in all_bits},
        "relation_to_coordinate": {name: list(perm_to_bits[p]) for name, p in permutations.items()},
        "reinin_forms_mask_bit0_E_bit1_I_bit2_J_bit3_D": reinin_forms,
        "characters": char_rows,
        "even_permutations": all(sign(p) == 0 for p in permutations.values()),
        "center": center,
        "commutator_subgroup": ["Тождество", "Суперэго"],
        "block_systems_size_2": blocks2,
        "block_systems_size_4": blocks4,
        "democrats_D0_action_orbits": orbits([bits_to_perm[x] for x in all_bits if x[3] == 0]),
        "irrationals_I0_action_orbits": orbits([bits_to_perm[x] for x in all_bits if x[1] == 0]),
        "position_coordinates_A_B_C": {str(p): list(fcoords[p]) for p in sorted(fcoords)},
        "aspect_coordinates_A_B_C": {a: list(acoords[a]) for a in aspects},
        "element_order_counts": {str(n): sum(order(p) == n for p in permutations.values()) for n in (1, 2, 4)},
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / "results.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (output / "traits.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(char_rows[0]))
        w.writeheader()
        w.writerows(char_rows)
    print("Verified 256 compositions, 128 model cells, 4096 brace/Yang--Baxter triples.")
    print(f"Saved: {output / 'results.json'} and {output / 'traits.csv'}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    args = parser.parse_args()
    main(args.source, args.output)

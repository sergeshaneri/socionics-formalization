# Проверяемый пакет: H16 и 8T9 (29 сентября 2026)

Запуск: python3 2026-09-29-fractal-8T9-check.py

Исходная таблица project_sources/09-markdown-1-.md предоставлена пользователем.
Для запуска нужен Python 3 без сторонних зависимостей.
Конвенция композиции: (p*q)(i)=p(q(i)).
Файл результатов содержит полный вывод проверок и привязку 16 типов к операторам отношений.

SHA-256:
113a2e92b4752b365eef89dacaf4ff0a40a5f742c2773c5808f6d9b0b0de99e3  2026-09-29-fraktal-H16-i-gruppa-8T9.md
56408c862d39c0b1df72bd91302cee30d8e375a9fe29516cae44c6ed3a49249d  2026-09-29-fraktal-H16-i-gruppa-8T9.pdf
b4d2d79b20cd81609584f1a96e038ab964c42196588c48ddccc3069906f992a6  2026-09-29-fractal-8T9-check.py
cc0c8af1ad11ac4ef7549396934447604461eaf0042f5f39300b297da7adde7c  2026-09-29-fractal-8T9-results.txt
92f80485da50f096f4094668db9a36be735e75c468e59adeef05c14f8fbea5f0  project_sources/09-markdown-1-.md

# Waffle products of all 16 trait systems

Research date: 2026-09-08. Main report and full partition appendix are in Russian with Obsidian-compatible LaTeX.

## Reproduce

Python 3.10 or later, standard library only, no network:

```bash
python3 code/reproduce.py
python3 code/build_report.py
```

The first script recreates results/ and checks all asserted identities. It can run from any working directory. The second regenerates REPORT.md and ALL_WAFFLE_PARTITIONS.md using code/report_template.md and the results. To recreate the console log as well, redirect the first command to results/run.log.

## Inputs and provenance

- inputs/systems.json contains all 16 published systems as exact pairs of eight-type sets, retaining Varlawend's numbering and names. Source: https://varlawend.blogspot.com/2023/08/there-are-16-distinct-systems-of-16.html . These factual partitions were obtained in the preceding study; every polynomial is reconstructed afresh from these sets, not taken from its conclusions.
- inputs/models.txt contains the 16 Model-A rows extracted from the user's project Markdown and used in the preceding study. Function numbering: 1 program, 2 creative, 3 role, 4 vulnerable, 5 suggestive, 6 mobilizing, 7 limiting, 8 background. These are the positions in this input, not a renumbered Functionon order.
- inputs/user_waffle_diagram.png is the original user attachment. Its X1..X8 labels are not equated with this report's W1..W15. The former refer to individual traits, the latter to entire eight-element cosets. The image is not a computational input.
- No full external article texts are redistributed.

## Conventions and encodings

Original raw code: E,N,L,I (positive pole 1). Normalized x=raw XOR 1111, ordered e,n,l,q. Their 1 poles are introvert, sensor, ethical, rational. d=n XOR l; d=1 means aristocratic. Quotient u=(e,d,q), encoded 4e+2d+q; t=n. ILE is zero.

All Boolean functions vanish at ILE. Products of signed traits are XOR of Boolean functions. Concatenation of variables in the ANF means AND. Complementary poles are identified by fixing the pole containing ILE to be zero.

k is encoded by bits 1,2,4,8 for monomials ed,eq,dq,edq. Thus W4 is dq+O (the Reinin/Tencer-Minaev waffle coset), W8 is edq+O. l is encoded as 4e+2d+q for the linear part. W numbering differs from source system numbering.

A truth-table mask is the integer sum f(x)*2**x over normalized original codes x=0..15. Its population count is the size of pole 1. See model_a_coordinates.csv for the full code/type mapping.

P_x is the permutation M_ILE^{-1} M_x. Composition acts rightmost first. Inversion pairs systems by h -> h+dq. Names in subgroup descriptions identify permutations through the reference ILE, not new psychological meanings of the types.

## Files and verification

All result CSV/JSON files are listed in REPORT.md. Full type poles for the 120 functions are provided both as JSON and as the separate Markdown appendix.

The pair-product CSV includes all 120*16*16 products. The Cayley CSV includes all 120*32*32 products. The waffle-product CSV includes all 15*15*8*8 products. All values are exact integers; cosines in the correlation CSV are exact multiples of 1/4.

The checks cover: reconstruction from source partitions, all model permutation products, group sizes and closure, disjointness, 15 matchings, all pole-size distributions, quadratic radicals and coset tetrads, cyclic/Klein subgroup types, cubic singled-out points and Fano incidence, all 28 point-pair/radical correspondences, inversion and cocycle transposition, group intersections, common 256-element group and its weight distribution.

SHA256SUMS.txt covers every archived file except itself. The ZIP is tested for integrity and extracted to a new location. Both scripts are executed there and every results file plus both Markdown reports is compared byte-for-byte to the originals.

"""Exact finite computation. Python >=3.10, standard library; no network."""
import json,csv,itertools,collections
from pathlib import Path
R=Path(__file__).resolve().parents[1]; ODIR=R/'results';ODIR.mkdir(exist_ok=True)
V=range(16);Q=range(8);HIGH=[6,5,3,7] # ed,eq,dq,edq

def dump(n,x): (ODIR/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def csvout(n,rows):
 with (ODIR/n).open('w',newline='',encoding='utf-8') as f:csv.writer(f).writerows(rows)
def p(x):return x.bit_count()%2
def u(x):return (x&8)//2|((((x>>2)^(x>>1))&1)<<1)|(x&1)
def t(x):return x>>2&1
def fromut(a,b):return ((a&4)<<1)|(b<<2)|((b^(a>>1&1))<<1)|(a&1)
def h(k,a):return sum(bool(k>>i&1) and a&m==m for i,m in enumerate(HIGH))%2
def lin(l,a):return p(l&a)
def poly(k,l=0):
 terms=[n for m,n in [(4,'e'),(2,'d'),(1,'q')] if l&m]
 terms += [n for i,n in enumerate(['ed','eq','dq','edq']) if k>>i&1]
 return '+'.join(terms) or '0'
def mask(fn):return sum(fn(x)<<x for x in V)
def anf(vals):
 a=list(vals)
 for b in (1,2,4):
  for i in Q:
   if i&b:a[i]^=a[i^b]
 return a
rows=[s.split() for s in (R/'inputs/models.txt').read_text().splitlines()]
names={int(r[1],2)^15:r[0] for r in rows};base=rows[0][2:]
P={int(r[1],2)^15:tuple(base.index(a) for a in r[2:]) for r in rows}
def op(x,y):return x^y^(6*((x&1)*(u(y)>>1&1)))
def inv(x):return x^(6*((x&1)*(u(x)>>1&1)))
assert all(tuple(P[x][P[y][i]] for i in range(8))==P[op(x,y)] for x in V for y in V)
signames={'I+':'ИЛЭ','I-':'ИЭЭ','S-':'СЭИ','S+':'СЛИ','E+':'ЭСЭ','E-':'ЭИЭ','L-':'ЛИИ','L+':'ЛСИ','F-':'СЛЭ','F+':'СЭЭ','T+':'ИЭИ','T-':'ИЛИ','P+':'ЛИЭ','P-':'ЛСЭ','R+':'ЭИИ','R-':'ЭСИ'}
signed={s:next(x for x in V if names[x]==n) for s,n in signames.items()}
orb={mask(lambda x:lin(l,u(x))) for l in Q}; sys={};index={};systemrows=[]
for a in json.loads((R/'inputs/systems.json').read_text()):
 walls=set()
 for aa,bb in a['pairs']:
  s={signed[z] for z in aa};z={signed[z] for z in bb};assert len(s)==len(z)==8 and s|z==set(V) and not s&z
  if 0 not in s:s,z=z,s
  walls.add(sum((x not in s)<<x for x in V))
 f=next(iter(walls));coeff=anf([(f>>fromut(v,0))&1 for v in Q]);k=sum(coeff[m]<<i for i,m in enumerate(HIGH))
 assert walls=={mask(lambda x:t(x)^h(k,u(x))^lin(l,u(x))) for l in Q}
 sys[a['id']]=orb|walls;index[k]=a['id'];systemrows.append(dict(id=a['id'],name=a['name'],k=k,h=poly(k)))
assert len(index)==16 and index[0]==15 and index[4]==14
W={k:{mask(lambda x:h(k,u(x))^lin(l,u(x))) for l in Q} for k in range(16)}
assert W[0]==orb and len(set().union(*W.values()))==128
wall={k:sys[index[k]]-orb for k in range(16)}
pairrows=[];products=[['system_i','system_j','function_i_mask','function_j_mask','product_mask']];groupelts=[];groups={};match=collections.defaultdict(list)
for i,j in itertools.combinations(sorted(sys),2):
 ki=next(k for k in index if index[k]==i);kj=next(k for k in index if index[k]==j);k=ki^kj
 G={a^b for a in sys[i] for b in sys[j]};assert len(G)==32 and G==sys[i]|sys[j]|W[k]
 assert len(sys[i]&sys[j])==8 and not W[k]&(sys[i]|sys[j])
 assert all(a^b in G for a in G for b in G)
 groups[i,j]=G;match[k].append([i,j]);pairrows.append([i,j,k,poly(k),32])
 for a in sorted(sys[i]):
  for b in sorted(sys[j]):products.append([i,j,a,b,a^b])
 for a in sorted(G):groupelts.append([i,j,a,','.join(names[x] for x in V if a>>x&1)])
assert len({frozenset(g) for g in groups.values()})==120
for k in match:assert len(match[k])==8 and sorted(sum(match[k],[]))==list(range(1,17))
# Cross-inner-products of the two orthogonal wall bases.
correlations=[['i','j','a_mask','b_mask','inner_product','cosine']]
for i,j,k,_,_ in pairrows:
 for a in sorted(sys[i]-orb):
  vals=[]
  for b in sorted(sys[j]-orb):
   ip=16-2*(a^b).bit_count();vals.append(abs(ip));correlations.append([i,j,a,b,ip,ip/16])
  assert collections.Counter(vals)==({0:4,8:4} if k<8 else {12:1,4:7})
csvout('wall_basis_correlations.csv',correlations)
# Every product in each 32-element group is retained.
cayley=[['i','j','a_mask','b_mask','product_mask']]
for (i,j),g in groups.items():
 for a in sorted(g):
  for b in sorted(g):cayley.append([i,j,a,b,a^b])
wf=[];wsummary=[];quadratic_tetrads=[];cubic_geometry=[]
for k in range(1,16):
 splits=collections.Counter();smallsets=[]
 for l in Q:
  f=mask(lambda x:h(k,u(x))^lin(l,u(x)));ones=[x for x in V if f>>x&1];zeros=[x for x in V if not f>>x&1]
  small=ones if len(ones)<len(zeros) else zeros if len(zeros)<len(ones) else None
  shape=f'{min(len(ones),len(zeros))}/{max(len(ones),len(zeros))}';splits[shape]+=1
  wf.append(dict(waffle_id=k,linear_mask=l,formula=poly(k,l),mask=f,zero_types=[names[x] for x in zeros],one_types=[names[x] for x in ones],split=shape,minority_types=None if small is None else [names[x] for x in small]))
  if small is not None:smallsets.append(set(small))
  assert all((f>>x&1)==(f>>(x^6)&1) for x in V)
 if k<8:
  assert splits=={'4/12':4,'8/8':4}
  rad=[r for r in range(1,8) if all(h(k,v)^h(k,r)^h(k,v^r)==0 for v in Q)];assert len(rad)==1;r=rad[0]
  H={x for x in V if u(x) in (0,r)};assert len(H)==4 and all(op(x,y) in H for x in H for y in H)
  assert all({op(x,z) for z in H}=={op(z,x) for z in H} for x in V)
  tetrads={frozenset(x for x in V if u(x) in (v,v^r)) for v in Q}
  assert {frozenset(s) for s in smallsets}==tetrads
  Htype='C4' if any(op(x,x)!=0 for x in H) else 'C2xC2'
  quadratic_tetrads.append(dict(k=k,formula=poly(k),radical=f'{r:03b}',subgroup_types=[names[x] for x in sorted(H)],subgroup_type=Htype,defining_orbital_functions=[poly(0,l) for l in range(1,8) if lin(l,r)==0],tetrads=[[names[x] for x in sorted(z)] for z in sorted(tetrads,key=lambda a:min(a))]))
 else:
  assert splits=={'2/14':1,'6/10':7}
  pair=next(s for s in smallsets if len(s)==2);point=u(next(iter(pair)))
  assert point==(((1^(k>>2&1))<<2)|((1^(k>>1&1))<<1)|(1^(k&1)))
  triples=[{u(x) for x in s} for s in smallsets if len(s)==6]
  planes=[{v for v in Q if lin(l,v)==lin(l,point)}-{point} for l in range(1,8)]
  assert {frozenset(z) for z in triples}=={frozenset(z) for z in planes}
  assert all(sum(v in z for z in triples)==3 for v in Q if v!=point)
  cubic_geometry.append(dict(k=k,formula=poly(k),distinguished_point=f'{point:03b}',distinguished_superego_pair=[names[x] for x in sorted(pair)],sextets=[[names[x] for x in sorted(z)] for z in smallsets if len(z)==6]))
 wsummary.append(dict(k=k,formula=poly(k),degree=2 if k<8 else 3,splits=dict(splits),pairs=match[k]))
# The line joining two distinguished cubic points is the quadratic radical.
for a,b in itertools.combinations(cubic_geometry,2):
 k=a['k']^b['k'];r=int(a['distinguished_point'],2)^int(b['distinguished_point'],2)
 assert next(z for z in quadratic_tetrads if z['k']==k)['radical']==f'{r:03b}'
for a in cubic_geometry:
 p0=int(a['distinguished_point'],2)
 sextets=[set(s) for s in a['sextets']]
 remaining=[{names[x] for x in V if u(x)==v} for v in Q if v!=p0]
 assert all(sum((s|t)<=z for z in sextets)==1 for s,t in itertools.combinations(remaining,2))
# Product of waffle cosets; triples of directions, 35 lines of PG(3,2).
wp=[['k','l','a_mask','b_mask','product_mask','output_coset']]
for k in range(1,16):
 for l in range(1,16):
  assert {a^b for a in W[k] for b in W[l]}==W[k^l]
  for a in sorted(W[k]):
   for b in sorted(W[l]):wp.append([k,l,a,b,a^b,k^l])
triples=sorted({tuple(sorted([k,l,k^l])) for k in range(1,16) for l in range(k+1,16)});assert len(triples)==35
# All 256 functions in the common generated group; inversion-induced pair and cocycle transpose.
globalgroup={mask(lambda x:b*t(x)^h(k,u(x))^lin(l,u(x))) for b in range(2) for k in range(16) for l in Q}
assert collections.Counter(min(f.bit_count(),16-f.bit_count()) for f in globalgroup)=={0:1,2:8,4:28,6:56,8:163}
assert len(globalgroup)==256 and all(a^b in globalgroup for a in globalgroup for b in globalgroup)
assert all({sum(((f>>inv(x))&1)<<x for x in V) for f in sys[index[k]]}==sys[index[k^4]] for k in range(16))
def omega(k,a,b):return (a&1)*(b>>1&1)^h(k,a)^h(k,b)^h(k,a^b)
assert all(omega(k^4,a,b)==omega(k,b,a) for k in range(16) for a in Q for b in Q)
# Pairings act by commuting involutions, exactly 15 distinct matchings.
assert all((h(k,u(x))^h(l,u(x)))==h(k^l,u(x)) for k in range(16) for l in range(16) for x in V)
# Full 32-group intersections explain coincident/different affine lines.
intersections=[]
for (ij,g),(kl,jg) in itertools.combinations(groups.items(),2):intersections.append([*ij,*kl,len(g&jg)])
assert collections.Counter(r[-1] for r in intersections)=={8:5040,16:2100}
for i,j,k,l,order in intersections:
 ki=next(a for a in index if index[a]==i);kj=next(a for a in index if index[a]==j)
 kk=next(a for a in index if index[a]==k);kl=next(a for a in index if index[a]==l)
 assert order==(16 if set((i,j))&set((k,l)) or ki^kj==kk^kl else 8)
dump('system_index.json',sorted(systemrows,key=lambda a:a['id']));dump('waffle_summary.json',wsummary);dump('all_120_waffle_traits.json',wf);dump('quadratic_tetrads.json',quadratic_tetrads);dump('cubic_fano_geometry.json',cubic_geometry);dump('direction_triples.json',triples)
csvout('all_120_system_pairs.csv',[['i','j','waffle_id','formula_k','generated_group_order']]+pairrows)
csvout('system_pair_products.csv',products);csvout('group32_elements.csv',[['i','j','mask','one_pole_types']]+groupelts);csvout('group32_cayley.csv',cayley);csvout('waffle_products.csv',wp);csvout('group32_intersections.csv',[['i','j','k','l','intersection_order']]+intersections)
csvout('global256_functions.csv',[['mask','one_pole_size','zero_pole_types','one_pole_types']]+[[f,f.bit_count(),','.join(names[x] for x in V if not f>>x&1),','.join(names[x] for x in V if f>>x&1)] for f in sorted(globalgroup)])
csvout('pairing_matrix.csv',[['system']+list(range(1,17))]+[[i]+[0 if i==j else next(k for k in index if index[k]==i)^next(k for k in index if index[k]==j) for j in range(1,17)] for i in range(1,17)])
csvout('model_a_coordinates.csv',[['type','original_normalized_code','quotient_edq','t','inverse_type','permutation_1_to_8']]+[[names[x],f'{x:04b}',f'{u(x):03b}',t(x),names[inv(x)],','.join(str(z+1) for z in P[x])] for x in V])
checks=dict(systems=16,system_pairs=120,system_pair_products=len(products)-1,distinct_waffle_cosets=15,waffle_traits=120,generated_group32_count=120,cayley_products=len(cayley)-1,waffle_products=len(wp)-1,quadratic_families=7,cubic_families=8,matchings=15,pairs_per_matching=8,direction_triples=35,all_quadratic_triples=sum(all(x<8 for x in z) for z in triples),inversion_pair_waffle_id=4,global_group_order=256,all_assertions_passed=True)
dump('checks.json',checks);print(json.dumps(checks,ensure_ascii=False,indent=2))

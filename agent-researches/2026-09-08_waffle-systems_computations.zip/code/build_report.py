from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
def load(n):return json.loads((R/'results'/n).read_text())
def table(headers,rows):return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,row))+' |' for row in rows])
s=(R/'code/report_template.md').read_text()
s=s.replace('{{SYSTEMS}}',table(['Система','Название','Каноническое $h$'],[[a['id'],a['name'],'$'+a['h']+'$'] for a in load('system_index.json')]))
s=s.replace('{{WAFFLES}}',table(['Восьмёрка','Формула $k$','Размеры полюсов','Все восемь порождающих пар'],[[f"$W_{{{a['k']}}}$",'$'+a['formula']+'$','4 × 4/12; 4 × 8/8' if a['degree']==2 else '1 × 2/14; 7 × 6/10',', '.join(f'({i}, {j})' for i,j in a['pairs'])] for a in load('waffle_summary.json')]))
qs=load('quadratic_tetrads.json')
s=s.replace('{{QUADRATIC}}',table(['Восьмёрка','$k$','Радикал $r=(e,d,q)$','Определяющие орбитальные функции','Тип $K_r$'],[[f"$W_{{{a['k']}}}$",'$'+a['formula']+'$',a['radical'],', '.join('$'+z+'$' for z in a['defining_orbital_functions']),'$C_4$' if a['subgroup_type']=='C4' else '$C_2\\times C_2$'] for a in qs]))
s=s.replace('{{TETRADS}}',table(['Восьмёрка','Тетрада 1','Тетрада 2','Тетрада 3','Тетрада 4'],[[f"$W_{{{a['k']}}}$"]+[', '.join(t) for t in a['tetrads']] for a in qs]))
cs=load('cubic_fano_geometry.json')
s=s.replace('{{CUBIC}}',table(['Восьмёрка','$k$','Точка $p$','Меньший полюс 2/14'],[[f"$W_{{{a['k']}}}$",'$'+a['formula']+'$',a['distinguished_point'],', '.join(a['distinguished_superego_pair'])] for a in cs]))
s=s.replace('{{FANO_EXAMPLE}}','\n'.join('- '+', '.join(z)+'.' for z in next(a for a in cs if a['k']==15)['sextets']))
s=s.replace('{{QUAD_TRIPLES}}','\n'.join('- '+', '.join(f'$W_{{{k}}}$' for k in row)+'.' for row in load('direction_triples.json') if all(k<8 for k in row)))
assert '{{' not in s
(R/'REPORT.md').write_text(s)
traits=load('all_120_waffle_traits.json');a=['# Полные полюса 120 вафельных признаков','', 'Дата: 8 сентября 2026 года. Формулы нормированы нулём на ИЛЭ; + означает XOR. Индекс W относится к восьмёрке, а не к X-индексам пользовательской схемы.','']
for k in range(1,16):
 a += [f'## Восьмёрка W{k}','',table(['Формула','Размеры полюсов','Полюс 0','Полюс 1'],[['$'+z['formula']+'$',z['split'],', '.join(z['zero_types']),', '.join(z['one_types'])] for z in traits if z['waffle_id']==k]),'']
(R/'ALL_WAFFLE_PARTITIONS.md').write_text('\n'.join(a)+'\n')

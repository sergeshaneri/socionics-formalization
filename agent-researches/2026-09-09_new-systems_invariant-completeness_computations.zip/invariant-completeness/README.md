# Model-A invariant completeness — 2026-09-09

Read report.md. Python 3.10+, standard library only.

```bash
python3 code/reproduce.py > results/run.log
python3 code/build_report.py
```

Paths resolve relative to the scripts. Input formulas come from the previous
minimal-formula study; their optimization is not repeated here. The current
study independently computes union profiles, closures, groups, correlations,
orbits, and all 63 feature-combination separation tests.

Full table automorphisms and source Model-A rows are checked again.
results/blocks.json also retains every function-subset aspect union (masks 0..255).

Independent archive verification:

```bash
python3 code/verify_archive.py /absolute/path/to/archive.zip
```

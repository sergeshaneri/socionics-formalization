import sys,tempfile,zipfile,subprocess,hashlib
from pathlib import Path
with tempfile.TemporaryDirectory(prefix='modela_complete_verify_') as d:
 with zipfile.ZipFile(sys.argv[1]) as z:
  assert z.testzip() is None;z.extractall(d)
 r=Path(d)/'invariant-completeness'
 with (r/'results/run.log').open('w') as f:subprocess.run([sys.executable,str(r/'code/reproduce.py')],stdout=f,check=True)
 subprocess.run([sys.executable,str(r/'code/build_report.py')],check=True)
 for line in (r/'SHA256SUMS.txt').read_text().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
 print('Verified: archive integrity and independent reproduction of all checksums.')

"""Exact orbit-separation audit. Python >=3.10, standard library."""
import json,itertools,collections
from pathlib import Path
R=Path(__file__).resolve().parents[1];O=R/'results';O.mkdir(exist_ok=True)
def read(n):return json.loads((R/'inputs'/n).read_text())
def dump(n,a):(O/n).write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
def comp(a,b):return tuple(a[b[i]] for i in range(len(a)))
def inv(a):return tuple(a.index(i) for i in range(len(a)))
def push(m,p):return sum(1<<p[i] for i in range(len(p)) if m>>i&1)
def norm(m,p):
 z=push(m,p);return z^(65535 if z&1 else 0)
rows=[r.split() for r in (R/'inputs/models.txt').read_text().splitlines()];base=rows[0][2:];P={int(r[1],2)^15:tuple(base.index(a) for a in r[2:]) for r in rows};names={int(r[1],2)^15:r[0] for r in rows};rev={p:x for x,p in P.items()};G=set(P.values());identity=tuple(range(8))
assert len(P)==16 and all(comp(p,q) in G for p in G for q in G)
autos=read('table_automorphisms1024.json');systems={s['label']:tuple(s['functions']) for s in read('systems24.json') if s['kind']=='new'};prof={int(k):v for k,v in read('profiles.json').items()};blocks=set(prof);parts=read('partitions.json');best=read('best_formulas.json')
for a in autos:assert all(P[a['pi'][x]][a['alpha'][i]]==a['beta'][P[x][i]] for x in range(16) for i in range(8))
# Independent table/source check and direct reconstruction of all union profiles.
source=(R/'inputs/project_tables.md').read_text();matched=set()
for line in source.splitlines():
 z=[s.strip() for s in line.replace(chr(92),'').replace('*','').split('|')[1:-1]]
 if z and z[0] in names.values() and len(z)==9 and set(z[1:])==set(base):
  x=next(x for x in P if names[x]==z[0]);assert tuple(base.index(v) for v in z[1:])==P[x];matched.add(x)
assert len(matched)==16
image={x:[push(b,P[x]) for b in range(256)] for x in P};relative={(x,y):rev[comp(inv(P[x]),P[y])] for x in P for y in P}
def cycle(p):
 unseen=set(range(8));sizes=[]
 while unseen:
  i=min(unseen);s=set();j=i
  while j not in s:s.add(j);j=p[j]
  unseen-=s;sizes.append(len(s))
 return tuple(sorted(sizes))
cyc={x:cycle(p) for x,p in P.items()};ctypes=sorted(set(cyc.values()));data={}
for b in sorted(blocks):
 xs=[x for x in P if b>>x&1];U=[0]*256
 for B in range(256):
  for x in xs:U[B]|=image[x][B]
 mu=[min(U[B].bit_count() for B in range(1,256) if B.bit_count()==k) for k in range(1,9)];assert mu==prof[b]['mu']
 closure=sum(all(image[x][1<<i]&~U[1<<i]==0 for i in range(8))<<x for x in P);assert closure==prof[b]['closure_all']==prof[b]['closure_min']
 minimum_B=[B for B in range(1,256) if U[B].bit_count()==mu[B.bit_count()-1]]
 direct_min_closure=sum(all(image[x][B]&~U[B]==0 for B in minimum_B)<<x for x in P)
 assert direct_min_closure==closure
 exact=[B for B in range(1,255) if U[B].bit_count()==B.bit_count()];assert exact==prof[b]['exact_function_masks']
 gens={P[relative[xs[0],x]] for x in xs};H={identity};todo=[identity]
 for g in todo:
  for h in gens:
   v=comp(g,h)
   if v not in H:H.add(v);todo.append(v)
 unseen=set(range(8));os=[]
 while unseen:
  orb={h[min(unseen)] for h in H};os.append(len(orb));unseen-=orb
 rh=collections.Counter(relative[x,y] for x in xs for y in xs);ch=collections.Counter(cyc[relative[x,y]] for x in xs for y in xs if x!=y)
 coords=[]
 for sid in ['1','25','16','30']:
  z=best[sid][str(b)];coords.append((z['polynomial_cost'][0],z['linear_cost'][0] if z['linear_cost'] else 99))
 data[b]=dict(function_subset_unions=U,types=[names[x] for x in sorted(xs)],mu=mu,closure=closure,exact_signature=[len(H),sorted(os)],H=sorted(rev[h] for h in H),relation_histogram=[rh[i] for i in range(16)],cycle_histogram=[ch[c] for c in ctypes],formula_signature=tuple(sorted(coords[:2]))+tuple(coords[2:]))
# Distinct effective actions, with a table-automorphism witness.
def actions(aa):
 by={}
 for a in aa:by.setdefault(tuple(a['pi']),a)
 return list(by.values())
contexts={'unmarked':autos}
for n,S in systems.items():contexts[n]=[a for a in autos if tuple(sorted(norm(f,a['pi']) for f in S))==S]
contexts_blocks={'unmarked':blocks}
for n in systems:contexts_blocks[n]={b for p in parts if p['system']==n for b in p['blocks']}
features=['mu','closure','exact','cycles','relations','formulas'];catalog=[];reports={};collision_rows=[]
for ctx,aa in contexts.items():
 effective=actions(aa);bb=contexts_blocks[ctx];alphas={tuple(a['alpha']) for a in aa};phis=[tuple(rev[comp(comp(a,P[x]),inv(a))] for x in range(16)) for a in sorted(alphas)]
 sigs={}
 for b in sorted(bb):
  d=data[b];hist=d['relation_histogram'];relcanon=min(tuple(hist[phi.index(j)] for j in range(16)) for phi in phis)
  sigs[b]=dict(mu=tuple(d['mu']),closure=min(push(d['closure'],a['pi']) for a in effective),exact=(d['exact_signature'][0],tuple(d['exact_signature'][1])),cycles=tuple(d['cycle_histogram']),relations=relcanon,formulas=tuple(tuple(z) for z in d['formula_signature']))
 remaining=set(bb);orbits=[]
 while remaining:
  b=min(remaining);w={}
  for a in effective:w.setdefault(push(b,a['pi']),a['id'])
  oo=set(w);assert oo<=remaining
  for c in oo:assert sigs[c]==sigs[b],(ctx,b,c)
  orbits.append(dict(context=ctx,representative=b,members=sorted(oo),size=len(oo),witness_triples=w,signatures=sigs[b]));remaining-=oo
 reports[ctx]={}
 for size in [8,4,2]:
  oo=[o for o in orbits if o['representative'].bit_count()==size];byrep={o['representative']:o for o in oo};results={}
  for count in range(1,len(features)+1):
   for comb in itertools.combinations(features,count):
    groups=collections.defaultdict(list)
    for o in oo:
     key=tuple(sigs[o['representative']][f] for f in comb);groups[key].append(o['representative'])
    key='+'.join(comb);results[key]=dict(classes=len(groups),complete=len(groups)==len(oo),collision_groups=[g for g in groups.values() if len(g)>1])
  minimal=[key for key,v in results.items() if v['complete'] and not any(results['+'.join(c)]['complete'] for k in range(1,len(key.split('+'))) for c in itertools.combinations(key.split('+'),k))]
  reports[ctx][size]=dict(blocks=sum(o['size'] for o in oo),orbits=len(oo),individual={f:results[f] for f in features},inclusion_minimal_complete_feature_sets=minimal,all_combinations=results)
  for f in features:
   for group in results[f]['collision_groups']:collision_rows.append(dict(context=ctx,size=size,feature=f,orbit_representatives=group))
 catalog+=orbits
 print(ctx,[(k,v['orbits'],v['inclusion_minimal_complete_feature_sets']) for k,v in reports[ctx].items()],flush=True)
dump('blocks.json',data);dump('orbits.json',catalog);dump('classification.json',reports);dump('collisions.json',collision_rows);dump('encoding.json',dict(type_indices=names,aspect_order=base,cycle_type_order=ctypes,feature_order=features))
# Some pairs of distinct orbits have equivalent unary information: explicit transporter.
witnesses=[]
for ctx in contexts:
 for size in [8,4,2]:
  for group in reports[ctx][size]['individual']['closure']['collision_groups']:
   b=group[0]
   for c in group[1:]:
    a=next(a for a in contexts[ctx] if push(data[b]['closure'],a['pi'])==data[c]['closure'])
    bp=push(b,a['pi']);assert bp!=c
    def unary(m):return tuple(sum(1<<j for j in range(8) if any(m>>x&1 and P[x][i]==j for x in P)) for i in range(8))
    assert unary(bp)==unary(c)
    # A tuple allowed by one block and absent from the other; positions 1 and 2 distinguish all types.
    x=next(x for x in P if (bp^c)>>x&1)
    witnesses.append(dict(context=ctx,size=size,first=b,second=c,triple=a['id'],transported_first=bp,common_closure=data[c]['closure'],distinguishing_type=x,distinguishing_pair=[base[P[x][0]],base[P[x][1]]],pair_in_first=bool(bp>>x&1),pair_in_second=bool(c>>x&1)))
dump('unary_collision_witnesses.json',witnesses)
# Canonical full two-function joint catalogs distinguish orbits because projection (1,2) is injective.
assert len({(P[x][0],P[x][1]) for x in P})==16
dump('checks.json',dict(verified=True,blocks=602,contexts=len(contexts),all_orbit_signatures_invariant=True,unary_and_minimizer_closures_reverified=True,all_63_feature_combinations_checked=True,pair_projection_injective=True,unary_collision_witnesses=len(witnesses)))
# Classify the systems themselves; one scalar separates their two full-model orbits.
sysout=[];remaining=set(systems)
while remaining:
 n=min(remaining);w={}
 for a in autos:
  S=tuple(sorted(norm(f,a['pi']) for f in systems[n]));target=next(k for k,v in systems.items() if v==S);w.setdefault(target,a['id'])
 oo=set(w);assert oo<=remaining;remaining-=oo
 counts={}
 for k in sorted(oo):
  poles={f for f in systems[k] if f}|{f^65535 for f in systems[k] if f}
  counts[k]=sum(data[p]['mu'][1]<=4 for p in poles)
 assert len(set(counts.values()))==1
 sysout.append(dict(representative=n,members=sorted(oo),witness_triples=w,number_of_poles_with_mu2_le4=counts))
assert len(sysout)==2 and {next(iter(o['number_of_poles_with_mu2_le4'].values())) for o in sysout}=={2,10}
dump('system_orbits.json',sysout)
# Collisions of relation histograms in R become equivalent after changing the marked system.
marked=[]
for size in [8,4,2]:
 for group in reports['B1_2'][size]['individual']['relations']['collision_groups']:
  b,c=group[:2];a=next(a for a in autos if push(b,a['pi'])==c)
  S=tuple(sorted(norm(f,a['pi']) for f in systems['B1_2']));target=next(k for k,v in systems.items() if v==S);assert target!='B1_2'
  marked.append(dict(first=b,second=c,first_types=data[b]['types'],second_types=data[c]['types'],triple=a['id'],source_system='B1_2',target_system=target,first_closure=data[b]['closure'],second_closure=data[c]['closure']))
dump('marked_relation_collisions.json',marked)
# Fullness of supplied table automorphisms (three generators suffice for the normalizer test).
normal=[]
for a in itertools.permutations(range(8)):
 ai=inv(a)
 if all(comp(comp(a,P[x]),ai) in G for x in [1,2,8]):normal.append(a)
assert len(normal)==64 and len({(tuple(a['alpha']),tuple(a['beta']),tuple(a['pi'])) for a in autos})==16*len(normal)
check=json.loads((O/'checks.json').read_text());check.update(full_table_automorphisms_verified=True,system_orbits=2,system_scalar_complete=True,unmarked_block_orbits=26,marked_system_block_orbits=60)
dump('checks.json',check)

"""Python 3, standard library only. Run from any working directory."""
import json,csv,itertools,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
V=range(16); Q=range(8)
def dump(n,o): (OUT/n).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def csvout(n,rows):
 with (OUT/n).open('w',newline='') as f:
  w=csv.writer(f);w.writerows(rows)
def parity(x): return x.bit_count()%2
def anf(vals):
 a=list(vals)
 for b in (1,2,4):
  for i in Q:
   if i&b:a[i]^=a[i^b]
 return [i for i in Q if a[i]]
def poly(ms):return '+'.join(''.join(n for b,n in [(4,'e'),(2,'d'),(1,'q')] if m&b) or '1' for m in ms) or '0'
def uv(x):return (x&8)//2 | ((((x>>2)^(x>>1))&1)<<1) | (x&1)
def tt(x):return (x>>2)&1
def fromut(u,t):return ((u&4)<<1)|(t<<2)|((t^((u>>1)&1))<<1)|(u&1)
def op(x,y):return x^y^(6*((x&1)*((uv(y)>>1)&1)))
def inv(x):return op(x,0)^(6*((x&1)*((uv(x)>>1)&1)))
def rel(x,y):return op(inv(x),y)
rows=[s.split() for s in (ROOT/'inputs/models.txt').read_text().splitlines()]
names={int(r[1],2)^15:r[0] for r in rows}; base=rows[0][2:]
P={int(r[1],2)^15:tuple(base.index(a) for a in r[2:]) for r in rows}
assert all(P[6][i]!=i and P[6][P[6][i]]==i for i in range(8))
assert all(tuple(P[x][P[y][i]] for i in range(8))==P[op(x,y)] for x in V for y in V)
signed={'I+':'ИЛЭ','I-':'ИЭЭ','S-':'СЭИ','S+':'СЛИ','E+':'ЭСЭ','E-':'ЭИЭ','L-':'ЛИИ','L+':'ЛСИ','F-':'СЛЭ','F+':'СЭЭ','T+':'ИЭИ','T-':'ИЛИ','P+':'ЛИЭ','P-':'ЛСЭ','R+':'ЭИИ','R-':'ЭСИ'}
signed={s:next(x for x in V if names[x]==n) for s,n in signed.items()}
systems=json.loads((ROOT/'inputs/systems.json').read_text())
summary=[]; selectors=[['system','relation_x','relation_type','quotient_v','selector_polynomial_in_source_type','weight_on_16_types']]; pairrows=[['system','source','target','source_code','target_code','xor_difference','actual_relation_code','superego_correction']]; cocrows=[['system','u','v','omega']]; counter={}; allwalls=set(); systemtraits=[]
for sys in systems:
 walls=[]
 for aa,bb in sys['pairs']:
  a={signed[s] for s in aa};b={signed[s] for s in bb};assert len(a)==len(b)==8 and a|b==set(V) and not a&b
  if 0 not in a:a,b=b,a
  vals=tuple(int(x not in a) for x in V)
  assert all(vals[x]^vals[x^6]==1 for x in V)
  walls.append(vals)
 assert len(set(walls))==8
 hraw=[walls[0][fromut(u,0)] for u in Q]; terms=anf(hraw); high=[m for m in terms if m.bit_count()>1]
 def h(u):return sum((u&m)==m for m in high)%2
 def coord(x):return (uv(x)<<1)|(tt(x)^h(uv(x)))
 rev={coord(x):x for x in V}; assert len(rev)==16
 def mul(a,b):return coord(op(rev[a],rev[b]))
 def omega(u,v):return (u&1)*((v>>1)&1)^h(u)^h(v)^h(u^v)
 expected={tuple(tt(x)^h(uv(x))^parity(k&uv(x)) for x in V) for k in Q}
 assert expected==set(walls)
 orbit={tuple(parity(k&uv(x)) for x in V) for k in Q};traits=orbit|expected;systemtraits.append(traits);allwalls|=expected
 assert all(tuple(a[i]^b[i] for i in V) in traits for a in traits for b in traits)
 assert all(sum((-1)**(a[i]^b[i]) for i in V)==0 for a in traits for b in traits if a!=b)
 assert all(omega(u,v)^omega(u^v,z)==omega(v,z)^omega(u,v^z) for u in Q for v in Q for z in Q)
 assert all(omega(u,u)==((u&1)*((u>>1)&1)) for u in Q)
 assert all(omega(u,v)^omega(v,u)==((u&1)*((v>>1)&1)^((v&1)*((u>>1)&1))) for u in Q for v in Q)
 rrad=[v for v in Q if all(omega(u,v)==0 for u in Q)];lrad=[u for u in Q if all(omega(u,v)==0 for v in Q)]
 sels={tuple(omega(u,v) for u in Q) for v in Q};sels.discard((0,)*8)
 for r in V:
  vals=[omega(u,uv(r)) for u in Q];selectors.append([sys['id'],r,names[r],uv(r),poly(anf(vals)),2*sum(vals)])
 for u in Q:
  for v in Q:cocrows.append([sys['id'],u,v,omega(u,v)])
 for x in V:
  for y in V:
   r=rel(x,y);d=coord(x)^coord(y);actual=coord(r);c=omega(uv(x),uv(x)^uv(y))
   assert actual==d^c
   pairrows.append([sys['id'],names[x],names[y],coord(x),coord(y),d,actual,c])
 # Right multiplication by r; action on code is affine iff lambda is additive.
 affine=[]
 for r in V:
  F=lambda a:coord(op(rev[a],r))^coord(r)
  if all(F(a^b)==F(a)^F(b) for a in V for b in V):affine.append(r)
 brace_bad=next(([a,b,c,mul(a,b^c),mul(a,b)^a^mul(a,c)] for a in V for b in V for c in V if mul(a,b^c)!=mul(a,b)^a^mul(a,c)),None)
 if brace_bad:counter[str(sys['id'])]={'brace_identity_failure_codes':brace_bad}
 assert (len(affine)==16)==(7 not in high)
 assert (brace_bad is None)==(7 not in high)
 # Fixed function permutation for additive coordinate difference iff corresponding right selector vanishes.
 fixed=[]
 for delta in V:
  rs={rel(x,rev[coord(x)^delta]) for x in V}
  assert len(rs)<=2
  if len(rs)==1:fixed.append(delta)
 assert len(fixed)==2*len(rrad)
 summary.append(dict(id=sys['id'],name=sys['name'],h=poly(high),anf_masks=high,ID_size=2*len(rrad),right_radical=rrad,left_radical=lrad,selector_count=len(sels),selectors=sorted(poly(anf(s)) for s in sels),affine_right_actions=len(affine),brace=brace_bad is None,correction_pairs=sum(omega(uv(x),uv(x)^uv(y)) for x in V for y in V)))
assert len(allwalls)==128
assert len({tuple(s['anf_masks']) for s in summary})==16
assert all(len(a&b)==8 for i,a in enumerate(systemtraits) for j,b in enumerate(systemtraits) if i!=j)
assert next(s for s in summary if s['id']==15)['h']=='0'
assert next(s for s in summary if s['id']==14)['h']=='dq'
dump('systems_summary.json',summary);dump('brace_counterexamples.json',counter)
csvout('selectors.csv',selectors);csvout('all_type_pair_relations.csv',pairrows);csvout('cocycles.csv',cocrows)
csvout('type_coordinates.csv',[['type','signed_label','raw_code','normalized_e_n_l_q','quotient_e_d_q','t_n','permutation_1_to_8']]+[[names[x],next(k for k,v in signed.items() if v==x),f'{x^15:04b}',f'{x:04b}',f'{uv(x):03b}',tt(x),' '.join(str(i+1) for i in P[x])] for x in V])
# All 135 nonconstant partitions: exhaustive concrete Model-A function -> aspect unions.
traits=set().union(*systemtraits);traits.discard((0,)*16)
image={x:{m:sum(1<<P[x][i] for i in range(8) if m>>i&1) for m in range(1,255)} for x in V}
invariants=[]
for no,f in enumerate(sorted(traits),1):
 halves=[[x for x in V if f[x]==v] for v in (0,1)]
 for side,xs in enumerate(halves):
  for k in range(1,5):
   candidates=[]
   for m in range(1,255):
    if m.bit_count()!=k:continue
    union=0
    for x in xs:union|=image[x][m]
    candidates.append((union.bit_count(),m,union))
   minimum=min(z[0] for z in candidates)
   witnesses=[{'functions':[i+1 for i in range(8) if m>>i&1],'aspects':[base[i] for i in range(8) if u>>i&1]} for count,m,u in candidates if count==minimum]
   invariants.append(dict(partition_id=no,truth_table=''.join(map(str,f)),side=side,types=[names[x] for x in xs],function_count=k,min_aspect_union=minimum,witnesses=witnesses))
dump('model_a_partition_invariants.json',invariants)
dump('checks.json',dict(model_permutation_products=256,systems=16,wall_partitions=len(allwalls),nonconstant_partitions=len(traits),system_pair_intersections=240,relation_pairs=4096,cocycle_triples=8192,affine_systems=sum(s['brace'] for s in summary),ID_distribution=dict(collections.Counter(s['ID_size'] for s in summary)),all_assertions_passed=True))
print(json.dumps(summary,ensure_ascii=False,indent=2))

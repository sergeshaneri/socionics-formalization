# Reproducible investigation: 16 trait systems and Model A

Run `python3 code/reproduce.py`. Python 3.10+; standard library only. No network access required. Output files are recreated in `results/`. Assertions stop the run if any checked identity fails.

The report is `REPORT.md` (Russian, Obsidian-compatible LaTeX).

## Input provenance

- `inputs/models.txt`: the 16 Model-A rows from the user's project Markdown, preserved in `inputs/model_a_source.md`.
- `inputs/systems.json`: factual unordered halves of the 128 wall partitions, transcribed by parsing the published literal lists in Varlawend's article, 2023-08-09: https://varlawend.blogspot.com/2023/08/there-are-16-distinct-systems-of-16.html . System numbering and names are retained.
- Hamza Ali's 2026-02-12 article was read in the publicly accessible text copy https://www.scribd.com/document/997058903/A-Representation-Theoretic-Framework-for-Intertype-Relations-in-Socionics . Original supplied URL: https://publish.obsidian.md/typology-repository/Typology/Socionics/Intertype+Relations/A+Representation-Theoretic+Framework+for+Intertype+Relations+in+Socionics . Current original page could not be retrieved. Full article text is not redistributed here.
- General brace terminology: https://arxiv.org/abs/1511.03171 .

## Conventions

Raw Andrew code: E,N,L,I with positive pole 1. Normalized original code x = raw XOR 1111, ordered e,n,l,q. Thus 1 means introvert, sensor, ethical, rational respectively. d=n XOR l; 1 means aristocratic. The identity type is ILE.

Quotient coordinate u=(e,d,q), encoded as 4e+2d+q. Original central coordinate t=n. New system coordinate C_h=(e,d,q,a), a=t XOR h(u), encoded as 8e+4d+2q+a.

P_x maps function positions through the Model-A row to reference ILE positions. Products are ordinary composition, rightmost first. Relative relation is P_x^{-1} P_y. All positions are numbered 1..8 in the supplied Model-A convention.

The relation is named in CSV by the type obtained by applying its P_r to the ILE reference. Direction-dependent psychological relation names are deliberately not used as input for any verification.

Signed type-label dictionary is explicit in code and checked against the complete Reinin system: I+=ILE, I-=IEE, S-=SEI, S+=SLI, E+=ESE, E-=EIE, L-=LII, L+=LSI, F-=SLE, F+=SEE, T+=IEI, T-=ILI, P+=LIE, P-=LSE, R+=EII, R-=ESI.

`selectors.csv` uses fixed relation r and varies source x in x*r. Its weight counts source types with correction 1, not the number of affected quotient points. `right_radical` concerns omega(u,v)=0 for every u. A right action and left action need not have the same selector.

ANF polynomial notation uses + for XOR, concatenation for AND. Coefficients are modulo 2. Functions are normalized to zero at ILE. Linear terms of h do not change the trait system and are removed.

## Coverage

All 16*16 source/target pairs for every system; all 8*8 cocycle values for every system; all 8^3 cocycle identities for every system; all affine-additivity tests; explicit failed brace identities; every partition in the 135-partition union. Model-A invariants enumerate every subset of 1,2,3,4 function positions and retain every minimum-union witness separately on each pole.

`results/run.log` is the console output from the initial complete run. Re-running without redirect writes the same summary to stdout. This log is not required as input.

`SHA256SUMS.txt` covers all files in the archive except itself. All datasets in `results/` were byte-compared after running the extracted archive independently. ZIP integrity was checked using Python's zipfile testzip().

from pathlib import Path
import json,itertools as it,collections as co
from fractions import Fraction
R=Path(__file__).resolve().parents[1];D=R/'data';O=R/'results';O.mkdir(exist_ok=True)
def load(n):return json.loads((D/(n+'.json')).read_text())
def save(n,x):(O/(n+'.json')).write_text(json.dumps(x,ensure_ascii=False,indent=2))
p=[tuple(v-1 for v in x['images']) for x in load('permutations')];names=[x['name'] for x in load('permutations')];m=load('multiplication');mt=m['table'];iv=m['inverses'];sg=load('subgroups');sid={frozenset(x['elements']):x['id'] for x in sg};sb={x['id']:x for x in sg};ALL=set(range(16));tg={t:x['id'] for t,x in load('type_to_relation').items()};gt={g:t for t,g in tg.items()};base=['ЧИ','БЛ','ЧС','БЭ','БС','ЧЭ','БИ','ЧЛ']
for a in ALL:
 for b in ALL:assert tuple(p[a][p[b][i]] for i in range(8))==p[mt[a][b]]
ls=(D/'tables.md').read_text().splitlines();tabs=[];cur=[]
for l in ls+['']:
 if l.startswith('|'):cur.append([x.strip().replace('\\','').replace('*','') for x in l.strip().strip('|').split('|')])
 elif cur:tabs.append(cur);cur=[]
tr=next(t for t in tabs if t[0][:2]==['ТИМ','Существование']);trs={r[0]:dict(zip(tr[0][1:],map(int,r[1:]))) for r in tr[2:] if r[0]};char={n:[2*trs[gt[g]][n]-1 for g in range(16)] for n in tr[0][1:]}
mods={r[0]:r[1:] for r in next(t for t in tabs if t[0][0]=='ТИМ' and 'Прогр.' in t[0][1])[2:] if r[0]}
assert len(mods)==len(trs)==16
assert all([mods[t].index(a) for a in base]==list(p[tg[t]]) for t in mods)
def closure(gens):
 h={0};todo=[0]
 while todo:
  a=todo.pop()
  for b in gens:
   c=mt[a][b]
   if c not in h:h.add(c);todo.append(c)
 return frozenset(h)
def subset(s):return frozenset(int(x)-1 for x in s)
def asp(s):return frozenset(base.index(x) for x in s.split())
def act(g,s):return frozenset(p[g][x] for x in s)
def stab(s):return frozenset(g for g in ALL if act(g,s)==s)
def part(bs):return tuple(sorted(tuple(sorted(b)) for b in bs))
def partact(g,q):return part([act(g,b) for b in q])
def left(P,a):return frozenset(mt[a][b] for b in P)
def right(P,a):return frozenset(mt[b][a] for b in P)
def rank(mat):
 a=[[Fraction(v) for v in r] for r in mat];k=0
 for j in range(len(a[0])):
  z=next((i for i in range(k,len(a)) if a[i][j]),None)
  if z is None:continue
  a[k],a[z]=a[z],a[k];v=a[k][j];a[k]=[x/v for x in a[k]]
  for i in range(len(a)):
   if i!=k and a[i][j]:
    v=a[i][j];a[i]=[x-v*y for x,y in zip(a[i],a[k])]
  k+=1
  if k==len(a):break
 return k
specs=[('Экстраверсия','block','ЧИ ЧЭ ЧЛ ЧС','1368'),('Иррациональность','block','ЧИ БС ЧС БИ','1357'),('Статика','block','ЧИ БЛ БЭ ЧС','1234'),('Беспечность','incidence','ЧИ БС','1458'),('Уступчивость','incidence','ЧЛ БЭ','1458'),('Интуиция','incidence','ЧИ БИ','1278'),('Логика','incidence','ЧЛ БЛ','1278'),('Весёлые','incidence','ЧЭ БЛ','1256'),('Рассудительность','incidence','ЧИ БС','1256'),('Конструктивизм','incidence','ЧЭ БЭ','1467'),('Тактика','incidence','ЧИ БИ','1467')]
records=[]
for n,kind,aa,ff in specs:
 X=asp(aa);F=subset(ff);P=frozenset(g for g in ALL if act(g,X)<=F);expected=frozenset(g for g in ALL if char[n][g]==1);assert P==expected
 U=stab(F);V=stab(X);orbit=sorted(set(act(g,X) for g in ALL),key=lambda x:tuple(sorted(x)));accepted=[Y for Y in orbit if Y<=F];transporters=[]
 for Y in accepted:
  gs=sorted(g for g in ALL if act(g,X)==Y);transporters.append({'image':[x+1 for x in sorted(Y)],'elements':gs,'representative':gs[0]})
 for t in transporters:assert set(t['elements'])=={mt[t['representative']][v] for v in V}
 doubles=[];remaining=set(P)
 while remaining:
  a=min(remaining);dc={mt[mt[u][a]][v] for u in U for v in V};assert dc<=P;doubles.append({'representative':a,'elements':sorted(dc)});remaining-=dc
 L=frozenset(a for a in ALL if left(P,a)==P);RR=frozenset(a for a in ALL if right(P,a)==P);H=closure({mt[a][iv[b]] for a in P for b in P})
 missing=[g for g in ALL if not (act(g,X)<=F or act(g,X)<=set(range(8))-F)];assert not missing
 rec={'trait':n,'kind':kind,'aspects':aa.split(),'X':[x+1 for x in sorted(X)],'F':[x+1 for x in sorted(F)],'pole':sorted(P),'H':sid[H],'L':sid[L],'R':sid[RR],'stabilizer_F':sid[U],'stabilizer_X':sid[V],'X_orbit':[[x+1 for x in sorted(y)] for y in orbit],'accepted_images':transporters,'double_cosets':doubles,'object_stabilizers_equal_pole_stabilizers':U==L and V==RR,'nonclosure_witness':next(([a,b,mt[a][b]] for a in P for b in P if mt[a][b] not in P),None),'character':char[n]}
 records.append(rec)
# Three pair-partition formulae: one partition already defines the character.
relspec=[('Демократизм',['ЧИ БЛ','ЧС БЭ','БС ЧЭ','БИ ЧЛ'],['12','34','56','78']),('Позитивизм',['ЧИ ЧЛ','ЧЭ ЧС','БС БЛ','БЭ БИ'],['18','25','36','47']),('Квестимность',['ЧИ БЛ','БС ЧЛ','ЧЭ БИ','БЭ ЧС'],['12','34','58','67'])]
for n,aa,ff in relspec:
 Q=part([asp(x) for x in aa]);F=part([subset(x) for x in ff]);assert Q==F
 orbit=sorted(set(partact(g,Q) for g in ALL));P=frozenset(g for g in ALL if partact(g,Q)==F);assert len(orbit)==2 and P==frozenset(g for g in ALL if char[n][g]==1)
 records.append({'trait':n,'kind':'matching','aspect_pairs':[x.split() for x in aa],'matching':[[x+1 for x in b] for b in Q],'matching_orbit':[[[x+1 for x in b] for b in q] for q in orbit],'pole':sorted(P),'H':sid[P],'L':sid[P],'R':sid[P],'character':char[n]})
# Process: quotient on four pairs and orientation character.
blocks=[subset(x) for x in ['17','28','35','46']];q=[]
for g in ALL:q.append(tuple(blocks.index(act(g,b)) for b in blocks))
c=(1,2,3,0)
orient=[]
for u in q:
 out=[0]*4
 for i in range(4):out[u[i]]=u[c[i]]
 assert tuple(out) in [c,(3,0,1,2)];orient.append(1 if tuple(out)==c else -1)
assert orient==char['Правые'];kernel=frozenset(g for g in ALL if q[g]==tuple(range(4)));P=frozenset(g for g in ALL if orient[g]==1)
records.append({'trait':'Правые','kind':'cycle','pole':sorted(P),'H':sid[P],'L':sid[P],'R':sid[P],'character':orient,'quotient_permutations_0based':q,'quotient_kernel':sid[kernel],'quotient_image_order':len(set(q)),'blocks':[[x+1 for x in sorted(b)] for b in blocks]})
# Affine coordinate realization in common Hadamard row order.
order=[0,4,5,1,7,3,2,6];aff=[]
for g in ALL:
 perm=[order.index(p[g][x]) for x in order];t=perm[0];lin=[v^t for v in perm];assert all(lin[a^b]==lin[a]^lin[b] for a in range(8) for b in range(8));aff.append({'g':g,'translation':t,'linear_map':lin})
linear=sorted(set(tuple(x['linear_map']) for x in aff));assert len(linear)==2
T=frozenset(x['g'] for x in aff if x['linear_map']==list(range(8)));assert sid[T]=='H27'
# Polynomial character / regular representations, exact Fourier coefficients.
cnames=list(char);chi=list(char.values());product_table={}
for a in cnames:
 product_table[a]={}
 for b in cnames:
  prod=[x*y for x,y in zip(char[a],char[b])];product_table[a][b]=cnames[chi.index(prod)]
left_actions={};reprprofiles=[]
for n,f in char.items():
 vectors=[[f[mt[iv[a]][g]] for g in ALL] for a in ALL]
 coeffs=[[sum(v[g]*char[k][g] for g in ALL)//16 if sum(v[g]*char[k][g] for g in ALL)%16==0 else str(Fraction(sum(v[g]*char[k][g] for g in ALL),16)) for k in cnames] for v in vectors]
 left_actions[n]=coeffs
 hom=all(f[mt[a][b]]==f[a]*f[b] for a in ALL for b in ALL)
 reprprofiles.append({'trait':n,'homomorphism':hom,'left_translation_span_dimension':rank(vectors),'left_translation_orbit_size':len(set(tuple(v) for v in vectors)),'coupled_traits':sorted({cnames[j] for coeff in coeffs for j,v in enumerate(coeff) if v!=0})})
# Orbital schemes: every G element fixes each G-orbital; no color action on those.
def orbitals(H):
 rem={(i,j) for i in range(8) for j in range(8)};out=[]
 while rem:
  x,y=min(rem);orb={(p[g][x],p[g][y]) for g in H};rem-=orb;out.append(orb)
 return out
orb=orbitals(ALL)
# coherent configurations of point-fiber-preserving groups; symmetry checked per orbit.
orbprofiles=[]
for h in ['H34','H27','H30','H33','H31','H32','H28']:
 obs=orbitals(sb[h]['elements']);orbprofiles.append({'subgroup':h,'orbital_count':len(obs),'symmetric':all({(y,x) for x,y in o}==o for o in obs),'orbitals':[[[x+1,y+1] for x,y in sorted(o)] for o in obs]})
save('formula_profiles',records);save('affine_realization',{'function_order_1based':[x+1 for x in order],'coordinate_bits':'index 0..7, standard XOR; XNOR labels obtained by complementing each bit','maps':aff,'linear_maps':linear,'translation_subgroup':sid[T]});save('representation_profiles',reprprofiles);save('left_actions',{'trait_order':cnames,'relation_order':names,'coefficients':left_actions});save('trait_product_table',product_table);save('orbital_profiles',orbprofiles)
print('FORMULAE')
for r in records:print(r['trait'],r['kind'],r['H'],r['L'],r['R'],[(x['representative'],len(x['elements'])) for x in r.get('double_cosets',[])],len(r.get('X_orbit',[])))
print('AFFINE',linear,'kernel cycle',sid[kernel]);print('REPR',reprprofiles)
# Coset decompositions link incidence dichotomies to the tetrad catalogue.
tets=load('tetrachotomies');blocklookup={frozenset(tg[t] for t in b['types']):(row['number'],i+1) for row in tets for i,b in enumerate(row['blocks'])};links=[]
for r in records:
 if r['kind']!='incidence':continue
 P=frozenset(r['pole']);U=frozenset(sb[r['L']]['elements']);V=frozenset(sb[r['R']]['elements']);assert len(U)==len(V)==4 and len(U&V)==2 and P==frozenset(mt[u][v] for u in U for v in V)
 assert r['object_stabilizers_equal_pole_stabilizers']
 poles=[]
 for sign,S in [(1,P),(-1,frozenset(ALL-P))]:
  lc=sorted({tuple(sorted(mt[g][v] for v in V)) for g in S});rc=sorted({tuple(sorted(mt[u][g] for u in U)) for g in S});assert len(lc)==len(rc)==2
  poles.append({'sign':sign,'left_cosets_of_V':[{'elements':list(b),'tetrad':blocklookup[frozenset(b)]} for b in lc],'right_cosets_of_U':[{'elements':list(b),'tetrad':blocklookup[frozenset(b)]} for b in rc]})
 links.append({'trait':r['trait'],'U':r['L'],'V':r['R'],'intersection':sid[U&V],'poles':poles})
save('coset_tetrad_links',links)
# Four 2-dimensional invariant spaces, their explicit matrices and irreducibility.
pairs=[['Беспечность','Рассудительность'],['Уступчивость','Весёлые'],['Интуиция','Тактика'],['Логика','Конструктивизм']];reps=[]
for basis in pairs:
 mats=[]
 for a in ALL:
  mat=[[sum(char[basis[j]][mt[iv[a]][g]]*char[basis[i]][g] for g in ALL)//16 for j in range(2)] for i in range(2)]
  assert all(sum(mat[i][j]*mat[k][j] for j in range(2))==(i==k) for i in range(2) for k in range(2));mats.append(mat)
 for a in ALL:
  for b in ALL:assert [[sum(mats[a][i][k]*mats[b][k][j] for k in range(2)) for j in range(2)] for i in range(2)]==mats[mt[a][b]]
 traces=[x[0][0]+x[1][1] for x in mats];assert sum(x*x for x in traces)==16
 ker=frozenset(a for a in ALL if mats[a]==[[1,0],[0,1]])
 reps.append({'basis':basis,'matrices':mats,'traces':traces,'kernel':sid[ker],'kernel_relations':[names[g] for g in sorted(ker)],'irreducible_character_norm_squared':1})
save('two_dimensional_representations',reps)
# Common three character generators and coefficient formulae for all traits.
orbital_names=['Экстраверсия','Иррациональность','Демократизм'];products=[]
for exps in it.product([0,1],repeat=3):
 vals=[1]*16
 for n,e in zip(orbital_names,exps):
  if e:vals=[a*b for a,b in zip(vals,char[n])]
 products.append({'exponents':exps,'trait':cnames[chi.index(vals)]})
save('character_basis',{'basis':orbital_names,'products':products})
# Explicit counterexample: ordinary orbitals cannot encode a nonconstant sign under G.
assert all({(p[g][x],p[g][y]) for x,y in o}==o for g in ALL for o in orb)
# Check standard affine geometry of all 4-element targets and full color action.
qorder={x:i for i,x in enumerate(order)}
for r in records:
 if 'F' in r:
  coords=[qorder[x-1] for x in r['F']];assert len(coords)==4 and coords[0]^coords[1]^coords[2]^coords[3]==0
color_perms=[]
for a in aff:color_perms.append(a['linear_map'])
save('summary',{'formulae_verified':len(records),'group_order':16,'character_count_including_constant':8,'nonhomomorphic_traits':8,'incidence_all_single_double_coset':True,'incidence_subgroup_orders':[4,4],'incidence_intersection_order':2,'incidence_closure_order':16,'regular_representation_decomposition':'8 one-dimensional + 4 two-dimensional summands; two inequivalent 2D types each twice','ordinary_G_orbitals':len(orb),'all_G_orbitals_fixed_by_G':True,'quotient_cycle_kernel':sid[kernel],'quotient_cycle_image_order':len(set(q)),'affine_linear_image_order':2,'affine_translation_subgroup':sid[T],'models_extracted':len(mods),'traits_extracted':len(trs)})
print('LINKS',[(x['trait'],x['U'],x['V'],x['intersection'],[z['tetrad'] for z in x['poles'][0]['left_cosets_of_V']],[z['tetrad'] for z in x['poles'][0]['right_cosets_of_U']]) for x in links]);print('2D',[(x['basis'],x['kernel'],x['kernel_relations']) for x in reps]);print('CHAR BASIS',products)
quotients=[]
for r in records:
 if r['kind']!='incidence':continue
 orbit=[frozenset(v-1 for v in y) for y in r['X_orbit']];images=[tuple(orbit.index(act(g,Y)) for Y in orbit) for g in ALL];core=frozenset(g for g in ALL if images[g]==tuple(range(4)));assert len(set(images))==8 and len(core)==2
 quotients.append({'trait':r['trait'],'orbit':r['X_orbit'],'permutations_0based':images,'core_of_V':sid[core],'image_order':8,'accepted_orbit_indices':[i for i,Y in enumerate(orbit) if Y<=set(v-1 for v in r['F'])]})
save('incidence_quotient_actions',quotients)
# Verify matrix coefficient identities, distinguish the two irreducible types.
for x in reps:
 for g in ALL:
  for j,n in enumerate(x['basis']):assert sum(x['matrices'][g][j])==char[n][g]
assert reps[0]['traces']==reps[1]['traces'] and reps[2]['traces']==reps[3]['traces'] and reps[0]['traces']!=reps[2]['traces']
assert closure([4,12,1])==frozenset(ALL)
save('checks',{'all_formula_poles_equal_trait_table':True,'models_count':16,'trait_rows':16,'group_products_checked':256,'all_eight_incidence_factorizations_exact':True,'all_incidence_object_stabilizers_are_pole_stabilizers':True,'all_sixteen_sign_functions_orthonormal':all(sum(a*b for a,b in zip(f,g))==(16 if i==j else 0) for i,f in enumerate(chi) for j,g in enumerate(chi)),'all_2d_representation_products_checked':1024,'all_2d_matrix_coefficients_match_traits':True,'two_inequivalent_2d_types':True,'ordinary_orbitals_fixed':True,'all_functional_targets_are_affine_planes':True,'all_incidence_pair_orbit_images_are_D8':True})
# Algebraic normal form in the canonical affine coordinates (u,v,w,q).
identity=list(range(8));coord={x['g']:x['translation']+8*(x['linear_map']!=identity) for x in aff};assert len(set(coord.values()))==16
anfs=[]
for n,f in char.items():
 vals=[0]*16
 for g in ALL:vals[coord[g]]=(1-f[g])//2
 coef=vals[:]
 for bit in range(4):
  for mask in range(16):
   if mask>>bit&1:coef[mask]^=coef[mask^(1<<bit)]
 terms=[i for i,c in enumerate(coef) if c]
 assert all((sum((mask & term) == term for term in terms)%2)==vals[mask] for mask in range(16))
 anfs.append({'trait':n,'monomial_masks':terms,'variables':['u','v','w','q'],'degree':max((x.bit_count() for x in terms),default=0)})
save('affine_coordinate_anf',anfs);print('ANF',[(x['trait'],x['monomial_masks']) for x in anfs])
# Central extension law and common multiplicativity defect of the eight incidence signs.
def coords(g):
 z=coord[g];return (z&1,(z>>1)&1,(z>>2)&1,(z>>3)&1)
for g in ALL:
 for h in ALL:
  u,v,w,q0=coords(g);a,b,c,d=coords(h)
  assert coords(mt[g][h])==(u^a,v^b^(q0&(b^c)),w^c^(q0&(b^c)),q0^d)
  for x in anfs:
   coeff=[int((1<<i) in x['monomial_masks']) for i in range(4)];f=char[x['trait']];defect=(-1)**((coeff[1]^coeff[2])*q0*(b^c));assert f[mt[g][h]]==f[g]*f[h]*defect
assert coords(10)==(0,1,1,0)
save('central_extension',{'variables':['u','v','w','q'],'coordinates':{str(g):coords(g) for g in ALL},'central_coordinates':['u','n=v+w','q','b=v'],'super_ego_id':10,'super_ego_coordinates':[0,1,1,0],'cocycle':'q(g)*n(h) over F2','multiplication_verified_products':256,'character_defect_verified':256*16})
# Auxiliary assertions used by the prose: complements, fibers, and the common coordinates.
for r in records:
 minus=ALL-set(r['pole']);assert sid[closure({mt[a][iv[b]] for a in minus for b in minus})]==r['H']
for h,n in [('H30','Позитивизм'),('H33','Квестимность')]:
 K=set(sb['H27']['elements'])&set(sb[h]['elements']);assert len(K)==4;obs=orbitals(K);assert len(obs)==16
 Q=next(r['matching'] for r in records if r['trait']==n);edges={(a-1,b-1) for pair in Q for a,b in [pair,pair[::-1]]}
 assert all(not (o&edges) or o<=edges for o in obs)
# Store the literal table row counts for both Hadamard structures.
aspecttab=next(t for t in tabs if t[0][0]=='' and len(t[0])==9 and 'дт/бт' in t[0]);functiontab=next(t for t in tabs if t[0][0]=='' and len(t[0])==9 and 'Оц/Сит' in t[0])
assert len(aspecttab[2:])==len(functiontab[2:])==8
save('source_extraction',{'models':len(mods),'type_trait_rows':len(trs),'aspect_trait_rows':len(aspecttab[2:]),'function_trait_rows':len(functiontab[2:]),'relation_permutations':len(p),'aspect_table':aspecttab,'function_table':functiontab})

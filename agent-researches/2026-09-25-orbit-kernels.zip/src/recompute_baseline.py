#!/usr/bin/env python3
"""Exact finite enumeration. Python standard library only. No GAP required."""
from pathlib import Path
from itertools import combinations, permutations, product
from collections import Counter, defaultdict
import json, csv, hashlib, platform

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'baseline-results'; OUT.mkdir(exist_ok=True)
def dump(name,obj):
    (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
text=(ROOT/'data/tables.md').read_text()
def cells(line): return [x.strip().replace('\\','').replace('*','') for x in line.strip().strip('|').split('|')]
tables=[]; current=[]
for line in text.splitlines()+['']:
    if line.startswith('|'): current.append(cells(line))
    elif current: tables.append(current);current=[]
modeltable=next(t for t in tables if t[0][0]=='ТИМ' and 'Прогр.' in t[0][1])
traittable=next(t for t in tables if t[0][0]=='ТИМ' and t[0][1]=='Существование')
ittable=next(t for t in tables if t[0][0]=='ИТО')
models={r[0]:r[1:] for r in modeltable[2:] if r[0]}
traits={r[0]:dict(zip(traittable[0][1:],map(int,r[1:]))) for r in traittable[2:] if r[0]}
assert len(models)==len(traits)==16
column_order=[int(s.split()[0])-1 for s in ittable[0][1:]]
names=[]; perms=[]
for r in ittable[2:]:
    names.append(r[0]); p=[None]*8
    for col,v in zip(column_order,r[1:]):p[col]=int(v)-1
    assert sorted(p)==list(range(8))
    perms.append(tuple(p))
E=tuple(range(8)); assert perms[0]==E and len(set(perms))==16
index={p:i for i,p in enumerate(perms)}
def mul(a,b):return tuple(a[b[i]] for i in range(len(a)))
def inverse(a):return tuple(a.index(i) for i in range(len(a)))
mt=[[index[mul(a,b)] for b in perms] for a in perms]
inv=[index[inverse(a)] for a in perms]
def closure(gens):
    out={0}; todo=[0]
    while todo:
        a=todo.pop()
        for b in gens:
            c=mt[a][b]
            if c not in out:out.add(c);todo.append(c)
    return frozenset(out)
G=frozenset(range(16))
subs={frozenset({0})};todo=list(subs)
while todo:
    h=todo.pop()
    for g in G-h:
        k=closure(tuple(h)+(g,))
        if k not in subs:subs.add(k);todo.append(k)
subs=sorted(subs,key=lambda h:(len(h),tuple(sorted(h))))
ids={h:f'H{i:02d}' for i,h in enumerate(subs)}
def min_gens(h):
    for n in range(5):
        for a in combinations(sorted(h-{0}),n):
            if closure(a)==h:return a
    raise AssertionError('generator bound')
def order(p):
    e=tuple(range(len(p)));a=e
    for n in range(1,100):
        a=mul(a,p)
        if a==e:return n
def cycle_type(p):
    seen=set();out=[]
    for x in range(len(p)):
        if x not in seen:
            y=x;n=0
            while y not in seen:seen.add(y);n+=1;y=p[y]
            out.append(n)
    return tuple(sorted(out))
def cycles(p):
    seen=set();out=[]
    for x in range(len(p)):
        if x not in seen:
            y=x;c=[]
            while y not in seen:seen.add(y);c.append(y+1);y=p[y]
            if len(c)>1:out.append('('+ ' '.join(map(str,c))+')')
    return ''.join(out) or '()'
def abstract(ps):
    n=len(ps); os=Counter(map(order,ps)); ab=all(mul(a,b)==mul(b,a) for a in ps for b in ps)
    if n==1:return '1'
    if n==2:return 'C2'
    if n==4:return 'C4' if os[4] else 'E4'
    if n==8:
        if ab:return 'C4xC2' if os[4] else 'E8'
        assert os[2]==5 and os[4]==2
        return 'D8'
    if n==16:return 'D8xC2' # certified by presentation below
    raise AssertionError((n,os,ab))
def orbit_info(h):
    remaining=set(range(8)); out=[]
    while remaining:
        x=min(remaining);orb=sorted({perms[g][x] for g in h});remaining-=set(orb)
        stabilizer=sorted(g for g in h if perms[g][x]==x)
        kernel=sorted(g for g in h if all(perms[g][y]==y for y in orb))
        image=sorted({tuple(orb.index(perms[g][y]) for y in orb) for g in h})
        typ=abstract(image)
        label={(1,'1'):'1T1',(2,'C2'):'2T1',(4,'C4'):'4T1',(4,'E4'):'4T2',(4,'D8'):'4T3',(8,'C4xC2'):'8T2',(8,'E8'):'8T3',(8,'D8'):'8T4',(8,'D8xC2'):'8T9'}[(len(orb),typ)]
        assert len(orb)*len(stabilizer)==len(h)
        assert len(image)*len(kernel)==len(h)
        out.append(dict(points=[y+1 for y in orb],representative=x+1,stabilizer=stabilizer,kernel=kernel,image_type=typ,image_order=len(image),transitive_id=label,image_permutations=[[y+1 for y in p] for p in image]))
    assert set.intersection(*(set(o['kernel']) for o in out))=={0}
    return out

# Independent completeness check: all 2^15 subsets containing the identity.
exhaustive=set()
for mask in range(1<<15):
    h=frozenset([0]+[g for g in range(1,16) if mask & (1<<(g-1))])
    if len(h) not in [1,2,4,8,16]:continue
    if all(mt[a][b] in h for a in h for b in h):exhaustive.add(h)
assert exhaustive==set(subs)

# Explicit D8 x C2 presentation witness.
witness=None
for r,s,t in product(range(1,16),repeat=3):
    if order(perms[r])!=4 or order(perms[s])!=2 or order(perms[t])!=2:continue
    d=closure([r,s])
    if len(d)!=8 or mt[mt[s][r]][s]!=inv[r] or t in d:continue
    if not all(mt[t][g]==mt[g][t] for g in G):continue
    if closure([r,s,t])==G:witness=dict(r=r,s=s,t=t);break
assert witness

gens={h:min_gens(h) for h in subs}
allp=list(permutations(range(8)))
def conjugate(p,g):
    out=[0]*8
    for x in range(8):out[p[x]]=p[g[x]]
    return tuple(out)
def conjugacy_witness(h,k):
    target={perms[g] for g in k}
    for p in allp:
        if all(conjugate(p,perms[g]) in target for g in gens[h]):return list(p)
    return None

records=[];s8reps=[];greps=[]
for h in subs:
    ps=[perms[g] for g in sorted(h)]; obs=orbit_info(h)
    signature=(len(h),tuple(sorted(len(o['points']) for o in obs)),tuple(sorted(Counter(map(cycle_type,ps)).items())))
    s8=None;w=None
    for rep,sig,cid in s8reps:
        if sig==signature:
            w=conjugacy_witness(h,rep)
            if w is not None:s8=cid;break
    if s8 is None:
        s8=f'P{len(s8reps)+1:02d}';s8reps.append((h,signature,s8));w=list(range(8))
    conj={frozenset(mt[mt[g][a]][inv[g]] for a in h) for g in G}
    canonical=min(conj,key=lambda h:tuple(sorted(h)))
    if canonical not in greps:greps.append(canonical)
    record=dict(id=ids[h],order=len(h),abstract_type=abstract(ps),elements=sorted(h),relations=[names[g] for g in sorted(h)],generators=list(gens[h]),generator_cycles=[cycles(perms[g]) for g in gens[h]],orbits=obs,orbit_sizes=sorted([len(o['points']) for o in obs],reverse=True),transitive=len(obs)==1,free=all(len(o['stabilizer'])==1 for o in obs),normal=len(conj)==1,G_class=f'C{greps.index(canonical)+1:02d}',G_conjugates=sorted(ids[k] for k in conj),S8_class=s8,S8_representative=ids[next(a for a,_,c in s8reps if c==s8)],S8_witness=[x+1 for x in w],cycle_inventory={'-'.join(map(str,k)):v for k,v in Counter(map(cycle_type,ps)).items()})
    record['point_stabilizers']={str(x+1):sorted(g for g in h if perms[g][x]==x) for x in range(8)}
    representative=next(a for a,_,c in s8reps if c==s8)
    assert {conjugate(w,perms[g]) for g in h}=={perms[g] for g in representative}
    records.append(record)
byid={r['id']:r for r in records}

# Match type labels to the given permutations using the ILE model only.
# Convention: position of a fixed ILE aspect -> its position in the target model.
base=models['ИЛЭ']
type_to_g={t:index[tuple(m.index(a) for a in base)] for t,m in models.items()}
assert len(set(type_to_g.values()))==16
trait_names={'Верт':'Экстраверсия','Бс/Пр':'Беспечность','Ит/Сн':'Интуиция','Дм/Ар':'Демократизм','+/-':'Позитивизм','Ус/Уп':'Уступчивость','Лг/Эт':'Логика','Сб/Об':'Весёлые','Кн/Эм':'Конструктивизм','Пц/Рз':'Правые','?/!':'Квестимность','Рс/Рш':'Рассудительность','Тк/Ст':'Тактика','Наль':'Иррациональность','Таль':'Статика'}
requested=['Верт','Наль','Таль','Дм/Ар','?/!','+/-','Пц/Рз']
dich=[]
for short in requested:
    ts=[t for t in traits if traits[t][trait_names[short]]==1]
    h=frozenset(type_to_g[t] for t in ts)
    assert h in subs and len(h)==8
    dich.append(dict(trait=short,types=ts,subgroup=ids[h]))

# Import the supplied 35 rows; do not regenerate the classification of triples.
class_text=(ROOT/'data/classification.md').read_text()
rows=[];last=None
for line in class_text.splitlines():
    if not line.startswith('|'):continue
    r=cells(line)
    if len(r)!=5 or not r[1].isdigit():continue
    if r[0]:last=r[0]
    rows.append(dict(number=int(r[1]),source_group=last,traits=r[2].split('; '),generation=r[3],variant=r[4]))
assert len(rows)==35
tetra=[]
for row in sorted(rows,key=lambda r:r['number']):
    blocks=defaultdict(list)
    for t in traits:
        blocks[tuple(traits[t][trait_names[s]] for s in row['traits'])].append(t)
    assert len(blocks)==4 and all(len(b)==4 for b in blocks.values())
    bout=[]
    for signs,b in sorted(blocks.items(),reverse=True):
        anchor=b[0];a=type_to_g[anchor]
        S=frozenset(mt[type_to_g[t]][inv[a]] for t in b)
        R=frozenset(mt[type_to_g[u]][inv[type_to_g[t]]] for t in b for u in b)
        h=closure(S)
        assert h==closure(R)
        # Generated subgroup is independent of anchor within this block.
        assert all(closure([mt[type_to_g[t]][inv[type_to_g[v]]] for t in b])==h for v in b)
        bad=next(((x,y,mt[x][y]) for x in sorted(S) for y in sorted(S) if mt[x][y] not in S),None)
        bout.append(dict(signs=signs,types=b,anchor=anchor,anchored_relations=sorted(S),all_internal_relations=sorted(R),closed=S==h,generated_subgroup=ids[h],missing_from_anchored=sorted(h-S),nonclosure_witness=bad))
    row['blocks']=bout
    union=frozenset(g for b in bout for g in b['all_internal_relations'])
    row['all_blocks_relation_union']=sorted(union)
    row['all_blocks_generated_subgroup']=ids[closure(union)]
    tetra.append(row)

# Catalog 8T9 witness using published LMFDB generators.
lmcycles=[[[1,3],[2,8],[4,6],[5,7]],[[4,5],[6,7]],[[1,8],[2,3],[4,5],[6,7]],[[1,5],[2,6],[3,7],[4,8]]]
def fromcycles(cs):
    p=list(range(8))
    for c in cs:
        for a,b in zip(c,c[1:]+c[:1]):p[a-1]=b-1
    return tuple(p)
lmgens=list(map(fromcycles,lmcycles));lm={E};todo=[E]
while todo:
    a=todo.pop()
    for b in lmgens:
        c=mul(a,b)
        if c not in lm:lm.add(c);todo.append(c)
assert len(lm)==16
lmw=next(p for p in allp if all(conjugate(p,perms[g]) in lm for g in gens[G]))
assert {conjugate(lmw,p) for p in perms}==lm

dump('permutations.json',[dict(id=i,name=names[i],images=[x+1 for x in p],cycles=cycles(p),order=order(p)) for i,p in enumerate(perms)])
dump('multiplication.json',dict(convention='a*b means apply b first, then a',names=names,table=mt,inverses=inv))
dump('subgroups.json',records)
dump('dichotomies.json',dich)
dump('tetrachotomies.json',tetra)
dump('type_to_relation.json',{t:dict(id=g,name=names[g]) for t,g in type_to_g.items()})
dump('inclusions.json',[dict(lower=ids[h],upper=ids[k]) for h in subs for k in subs if h<k and not any(h<j<k for j in subs)])
summary=dict(subgroups=len(subs),orders=dict(Counter(len(h) for h in subs)),G_classes=len(greps),S8_classes=len(s8reps),S8_summary=[dict(class_id=cid,abstract_type=byid[ids[h]]['abstract_type'],orbits=byid[ids[h]]['orbit_sizes'],members=[r['id'] for r in records if r['S8_class']==cid]) for h,_,cid in s8reps],closed_tetrachotomies=[r['number'] for r in tetra if all(b['closed'] for b in r['blocks'])],tetra_closure_profiles={str(r['number']):sorted(set(byid[b['generated_subgroup']]['abstract_type'] for b in r['blocks'])) for r in tetra},presentation_witness=witness,lmfdb_8T9_witness=[x+1 for x in lmw],checks=dict(permutation_rows=16,all_products_in_table=256,exhaustive_identity_containing_subsets=32768,enumerations_agree=True,orbit_stabilizer=True,kernel_intersections_trivial=True,all_140_tetrads_have_4_types=True,closure_independent_of_anchor=True),python=platform.python_version())
dump('summary.json',summary)
for fname,items,fields in [('subgroups.csv',records,['id','order','abstract_type','relations','generator_cycles','orbit_sizes','G_class','S8_class','normal','free']),('tetrachotomies.csv',tetra,['number','source_group','traits','variant'])]:
    with (OUT/fname).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(items)
dump('manifest.json',{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'data').iterdir())})
print(json.dumps(summary,ensure_ascii=False,indent=2))
print('DICHOTOMIES')
for d in dich:
    r=byid[d['subgroup']]
    print(d['trait'],r['id'],r['abstract_type'],[o['points'] for o in r['orbits']],r['S8_class'],[o['kernel'] for o in r['orbits']])

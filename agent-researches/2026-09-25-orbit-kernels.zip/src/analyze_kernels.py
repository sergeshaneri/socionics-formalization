#!/usr/bin/env python3
"""Supplementary exact checks and incidence counts; Python stdlib only."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import product
import json,csv,hashlib,platform
ROOT=Path(__file__).resolve().parents[1]
B=ROOT/'baseline-results';OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
def load(name):return json.loads((B/name).read_text())
def save(name,value): (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
S=load('subgroups.json');T=load('tetrachotomies.json');D=load('dichotomies.json');P=load('permutations.json');M=load('multiplication.json')['table'];sd={s['id']:s for s in S}
def compose(p,q):return tuple(p[x-1] for x in q)
perms={p['id']:tuple(p['images']) for p in P}
def restrict(g,points):return tuple(perms[g][x-1] for x in points)
E=tuple(range(1,9))
profiles=[]
for h in S:
    obs=[]
    for o in h['orbits']:
        pts=o['points'];kernel=[g for g in h['elements'] if restrict(g,pts)==tuple(pts)]
        assert kernel==o['kernel']
        image={restrict(g,pts) for g in h['elements']}
        assert len(image)==o['image_order']
        stabs={str(x):[g for g in h['elements'] if perms[g][x-1]==x] for x in pts}
        assert set.intersection(*(set(a) for a in stabs.values()))==set(kernel)
        fibers=Counter(restrict(g,pts) for g in h['elements'])
        assert set(fibers.values())=={len(kernel)}
        obs.append(dict(points=pts,kernel=kernel,faithful=len(kernel)==1,free=all(len(v)==1 for v in stabs.values()),stabilizer_orders={x:len(a) for x,a in stabs.items()},image_order=len(image),transitive_id=o['transitive_id'],fibers=[dict(images=k,preimages=[g for g in h['elements'] if restrict(g,pts)==k]) for k in sorted(image)]))
    joint={tuple(restrict(g,o['points']) for o in h['orbits']) for g in h['elements']}
    assert len(joint)==h['order']
    profiles.append(dict(id=h['id'],abstract_type=h['abstract_type'],generators=h['generators'],orbits=obs,joint_order=len(joint),product_order=__import__('math').prod(o['image_order'] for o in h['orbits'])))
save('all_orbit_profiles.json',profiles)

# Delo and Rod are precisely the two possible nontrivial point stabilizers in G.
fixed={str(x):[g for g in range(16) if perms[g][x-1]==x] for x in range(1,9)}
assert all(fixed[str(x)]==([0,12] if x in [1,3,5,7] else [0,6]) for x in range(1,9))
for h in S:
    for x in range(1,9):
        assert sorted(set(h['elements'])&set(fixed[str(x)]))==h['point_stabilizers'][str(x)]
save('point_stabilizer_rule.json',fixed)

# Du is central and gives an H-equivariant matching between both D8 orbits.
assert all(M[1][g]==M[g][1] for g in range(16))
diagonal=[]
for hid in ['H30','H33']:
    h=sd[hid];A,Bb=[o['points'] for o in h['orbits']]
    J={x:perms[1][x-1] for x in A}
    assert set(J.values())==set(Bb)
    assert all(perms[g][J[x]-1]==J[perms[g][x-1]] for g in h['elements'] for x in A)
    pairs=[dict(relation_id=g,on_first=restrict(g,A),on_second=restrict(g,Bb)) for g in h['elements']]
    assert len({tuple(r['on_first']) for r in pairs})==len({tuple(r['on_second']) for r in pairs})==8
    diagonal.append(dict(id=hid,first=A,second=Bb,matching=J,pairs=pairs,joint_order=8,product_order=64))
save('diagonal_D8.json',diagonal)

# Nality = <Du,Delo,Rod>, unique coordinates u,a,b in F2.
n=sd['H29'];A,Bb=[o['points'] for o in n['orbits']];coordinates=[]
for u,a,b in product(range(2),repeat=3):
    g=0
    for flag,gen in [(u,1),(a,6),(b,12)]:
        if flag:g=M[g][gen]
    coordinates.append(dict(coordinates=[u,a,b],relation_id=g,first_coordinates=[u,a],second_coordinates=[u,b],on_first=restrict(g,A),on_second=restrict(g,Bb)))
assert {r['relation_id'] for r in coordinates}==set(n['elements'])
assert len(set(r['relation_id'] for r in coordinates))==8
for x in coordinates:
    for y in coordinates:
        assert (x['on_first']==y['on_first'])==(x['first_coordinates']==y['first_coordinates'])
        assert (x['on_second']==y['on_second'])==(x['second_coordinates']==y['second_coordinates'])
save('nality_fiber_product.json',dict(first=A,second=Bb,rows=coordinates,joint_order=8,product_order=16,compatibility='first_coordinates[0] == second_coordinates[0]'))

# Distinct notions of counting.
counts=[]
for h in S:
    local=[];global_numbers=[];contained=[]
    for t in T:
        n=sum(b['generated_subgroup']==h['id'] for b in t['blocks'])
        if n:local.append(dict(number=t['number'],tetrads=n))
        if t['all_blocks_generated_subgroup']==h['id']:global_numbers.append(t['number'])
        if set(sd[t['all_blocks_generated_subgroup']]['elements'])<=set(h['elements']):contained.append(t['number'])
    counts.append(dict(id=h['id'],abstract_type=h['abstract_type'],generators=h['generators'],relations=h['relations'],local=local,local_distinct_tetrachotomies=len(local),local_tetrad_count=sum(x['tetrads'] for x in local),whole_group_exact=global_numbers,whole_group_contained=contained))
assert sum(c['local_tetrad_count'] for c in counts)==140
assert sum(len(c['whole_group_exact']) for c in counts)==35
save('subgroup_incidence.json',counts)

# Use the given triples as formulas, preserving their numbering.
orbital={d['trait'] for d in D};formula_groups=defaultdict(list)
for t in T:
    inside=sorted(set(t['traits'])&orbital)
    assert len(inside) in (1,3)
    key='three_orbital' if len(inside)==3 else inside[0]
    formula_groups[key].append(t['number'])
assert len(formula_groups['three_orbital'])==7
assert all(len(formula_groups[k])==4 for k in orbital)
for d in D:
    numbers={t['number'] for t in T if d['trait'] in t['traits']}
    entry=next(c for c in counts if c['id']==d['subgroup'])
    assert numbers==set(entry['whole_group_contained']) and len(numbers)==7
save('formula_groups.json',dict(formula_groups))

flat=[]
for t in T:
    for b in t['blocks']:
        flat.append(dict(number=t['number'],traits='; '.join(t['traits']),types='; '.join(b['types']),anchor=b['anchor'],S='; '.join(P[g]['name'] for g in b['anchored_relations']),R='; '.join(P[g]['name'] for g in b['all_internal_relations']),H_B=b['generated_subgroup'],H_partition=t['all_blocks_generated_subgroup'],closed=b['closed']))
with (OUT/'all_140_tetrads.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(flat[0]));w.writeheader();w.writerows(flat)
save('checks.json',dict(python=platform.python_version(),subgroups=len(S),tetrads=len(flat),tetrachotomies=len(T),all_kernels_recomputed=True,all_fiber_sizes_equal_kernel_orders=True,all_joint_actions_faithful=True,point_stabilizer_rule_verified_for_all_subgroups=True,dual_equivariance_for_two_D8=True,nality_binary_model_bijective=True,local_tetrad_count=140,whole_group_exact_count=35,local_incidence_count=sum(c['local_distinct_tetrachotomies'] for c in counts),formula_split='7 + 7*4 = 35'))
save('input_sha256.json',{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ['baseline-results','data'] for p in sorted((ROOT/d).iterdir()) if p.is_file()})
print(json.dumps(load('summary.json')['orders'],ensure_ascii=False))
print(json.dumps(dict(formula_groups),ensure_ascii=False,indent=2))
print('All supplementary checks passed.')
